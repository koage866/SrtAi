package com.example

import com.example.utils.SrtParser
import org.junit.Assert.assertEquals
import org.junit.Test

class GreetingScreenshotTest {

    @Test
    fun srt_parser_test() {
        val rawSrt = "1\n00:00:01,000 --> 00:00:04,000\nHello World!"
        val clean = SrtParser.extractCleanText(rawSrt)
        assertEquals("Hello World!", clean)
    }
}
