package com.example.data.model

import android.net.Uri

data class SubtitleItem(
    val index: Int,
    val startTime: String, // e.g. "00:00:01,000"
    val endTime: String,   // e.g. "00:00:04,500"
    val text: String
)

data class VideoInfo(
    val uri: Uri,
    val fileName: String,
    val durationFormatted: String,
    val fileSizeFormatted: String,
    val isSample: Boolean = false
)

enum class VoiceGender {
    MALE, FEMALE, NEUTRAL
}

data class VoiceProfile(
    val id: String,
    val name: String,
    val gender: VoiceGender,
    val pitch: Float,
    val speechRate: Float,
    val description: String,
    val isDefault: Boolean = false
) {
    companion object {
        val PRESETS = listOf(
            VoiceProfile(
                id = "male_deep",
                name = "Male (Deep Narrator)",
                gender = VoiceGender.MALE,
                pitch = 0.70f,
                speechRate = 0.95f,
                description = "Low pitch, deep cinematic voiceover"
            ),
            VoiceProfile(
                id = "male_standard",
                name = "Male (Standard Voice)",
                gender = VoiceGender.MALE,
                pitch = 0.88f,
                speechRate = 1.0f,
                description = "Natural male voiceover tone",
                isDefault = true
            ),
            VoiceProfile(
                id = "female_natural",
                name = "Female (Natural / Bright)",
                gender = VoiceGender.FEMALE,
                pitch = 1.25f,
                speechRate = 1.0f,
                description = "Clear, bright female voiceover"
            ),
            VoiceProfile(
                id = "female_soft",
                name = "Female (Warm / Soft)",
                gender = VoiceGender.FEMALE,
                pitch = 1.15f,
                speechRate = 0.95f,
                description = "Calm and warm conversational tone"
            ),
            VoiceProfile(
                id = "neutral_broadcast",
                name = "Neutral (News Broadcast)",
                gender = VoiceGender.NEUTRAL,
                pitch = 1.0f,
                speechRate = 1.05f,
                description = "Crisp news anchor voice"
            )
        )
    }
}

