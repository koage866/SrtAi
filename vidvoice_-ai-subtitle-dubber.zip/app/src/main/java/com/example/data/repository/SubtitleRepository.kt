package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.api.GeminiContent
import com.example.data.api.GeminiGenerationConfig
import com.example.data.api.GeminiInlineData
import com.example.data.api.GeminiPart
import com.example.data.api.GeminiRequest
import com.example.data.api.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream

class SubtitleRepository(private val context: Context) {

    suspend fun generateSrtFromVideo(videoUri: Uri, isSample: Boolean = false): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (isSample) {
                // Return sample SRT in Myanmar language
                val sampleSrt = """
                    1
                    00:00:00,500 --> 00:00:03,800
                    မင်္ဂလာပါ! ဗီဒီယို စာတန်းထိုးနှင့် အသံထွက် စနစ်မှ ကြိုဆိုပါတယ်။

                    2
                    00:00:04,100 --> 00:00:08,200
                    ဒီဆော့ဖ်ဝဲသည် Gemini AI ကို အသုံးပြု၍ ဗီဒီယိုအသံမှ မြန်မာစာတန်းထိုး စာသားများကို တိကျစွာ ထုတ်လုပ်ပေးပါသည်။

                    3
                    00:00:08,500 --> 00:00:12,600
                    စာတန်းထိုး စာသားများကို စိတ်ကြိုက် ပြင်ဆင်နိုင်ပြီး TTS အသံဖြင့် နားထောင်ကာ ဒေါင်းလုဒ် ရယူနိုင်ပါသည်။

                    4
                    00:00:13,000 --> 00:00:16,500
                    စာသားများကို ပြင်ဆင်ရန် သို့မဟုတ် သင့် ဗီဒီယို ဖိုင်ကို တင်သွင်း၍ စတင် စမ်းသပ်ကြည့်ပါ။
                """.trimIndent()
                return@withContext Result.success(sampleSrt)
            }

            val apiKeyManager = com.example.utils.ApiKeyManager(context)
            val apiKey = apiKeyManager.getEffectiveApiKey()
            if (apiKey.isBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("Gemini API Key မရှိသေးပါ။ ကျေးဇူးပြု၍ API Key ထည့်သွင်းပေးပါ။ (Gemini API Key is missing. Please enter your API Key in Settings.)")
                )
            }

            // Read video bytes and convert to Base64
            val contentResolver = context.contentResolver
            val mimeType = contentResolver.getType(videoUri) ?: "video/mp4"

            val inputStream: InputStream? = contentResolver.openInputStream(videoUri)
            val bytes = inputStream?.use { it.readBytes() }
                ?: return@withContext Result.failure(IllegalStateException("Unable to read video file content."))

            // Check file size constraint for inline data (~20MB max for base64 payload)
            if (bytes.size > 22 * 1024 * 1024) {
                return@withContext Result.failure(
                    IllegalArgumentException("Video file size is over 20MB. Please select a smaller video clip or clip segment.")
                )
            }

            val base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP)

            val prompt = """
                Analyze the spoken audio track of this video and generate a complete, formatted SRT subtitle file in Myanmar (Burmese / မြန်မာဘာသာ) language with precise timestamps. Translate or transcribe the spoken speech into clear, natural, accurate Burmese (Myanmar) language.
                
                Requirements:
                1. Strictly follow the standard SRT format:
                   [Sequence Number]
                   [Start Time] --> [End Time] (format: HH:MM:SS,mmm)
                   [Spoken text in Myanmar / Burmese (မြန်မာဘာသာ)]
                2. Do NOT surround the output in markdown code blocks like ```srt or ```.
                3. Do NOT include any intro, commentary, or extra explanations.
                4. Return ONLY the valid SRT text content.
            """.trimIndent()

            val request = GeminiRequest(
                contents = listOf(
                    GeminiContent(
                        parts = listOf(
                            GeminiPart(text = prompt),
                            GeminiPart(
                                inlineData = GeminiInlineData(
                                    mimeType = mimeType,
                                    data = base64Data
                                )
                            )
                        )
                    )
                ),
                generationConfig = GeminiGenerationConfig(temperature = 0.2f)
            )

            val response = RetrofitClient.geminiService.generateContent(apiKey, request)
            val generatedText = response.candidates
                ?.firstOrNull()
                ?.content
                ?.parts
                ?.firstOrNull()
                ?.text

            if (!generatedText.isNullOrBlank()) {
                val cleanSrt = generatedText
                    .replace("```srt", "")
                    .replace("```", "")
                    .trim()
                Result.success(cleanSrt)
            } else {
                Result.failure(Exception("Gemini returned empty transcription response."))
            }
        } catch (e: Exception) {
            Log.e("SubtitleRepository", "Error generating SRT from video", e)
            Result.failure(e)
        }
    }
}
