package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.model.VideoInfo

object SampleVideoData {

    // A reliable online MP4 sample video URL for testing video playback & transcription
    val SAMPLE_VIDEO_URI: Uri = Uri.parse("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4")

    fun getSampleVideoInfo(): VideoInfo {
        return VideoInfo(
            uri = SAMPLE_VIDEO_URI,
            fileName = "sample_presentation_clip.mp4",
            durationFormatted = "00:15",
            fileSizeFormatted = "3.2 MB",
            isSample = true
        )
    }
}
