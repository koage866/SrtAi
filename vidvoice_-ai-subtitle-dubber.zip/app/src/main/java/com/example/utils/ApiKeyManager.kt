package com.example.utils

import android.content.Context
import com.example.BuildConfig

class ApiKeyManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("app_settings_prefs", Context.MODE_PRIVATE)

    fun getUserApiKey(): String {
        return prefs.getString(KEY_GEMINI_API_KEY, "") ?: ""
    }

    fun saveApiKey(key: String) {
        prefs.edit().putString(KEY_GEMINI_API_KEY, key.trim()).apply()
    }

    fun clearApiKey() {
        prefs.edit().remove(KEY_GEMINI_API_KEY).apply()
    }

    fun getEffectiveApiKey(): String {
        val userKey = getUserApiKey()
        if (userKey.isNotBlank()) {
            return userKey
        }
        val buildKey = BuildConfig.GEMINI_API_KEY
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") {
            return buildKey
        }
        return ""
    }

    fun hasValidApiKey(): Boolean {
        return getEffectiveApiKey().isNotBlank()
    }

    companion object {
        private const val KEY_GEMINI_API_KEY = "user_gemini_api_key"
    }
}
