package com.example.utils

import com.example.data.model.SubtitleItem

object SrtParser {

    /**
     * Parses raw SRT content string into a list of SubtitleItem objects.
     */
    fun parse(srtContent: String): List<SubtitleItem> {
        val items = mutableListOf<SubtitleItem>()
        if (srtContent.isBlank()) return items

        val blocks = srtContent.trim().split(Regex("\\r?\\n\\s*\\r?\\n"))
        for (block in blocks) {
            val lines = block.trim().lines()
            if (lines.size >= 2) {
                val index = lines[0].trim().toIntOrNull() ?: (items.size + 1)
                val timeLineIndex = lines.indexOfFirst { it.contains("-->") }

                if (timeLineIndex != -1) {
                    val timeLine = lines[timeLineIndex]
                    val parts = timeLine.split("-->")
                    val rawStart = parts.getOrNull(0)?.trim() ?: "00:00:00,000"
                    val rawEnd = parts.getOrNull(1)?.trim() ?: "00:00:05,000"

                    val startTime = normalizeTimestamp(rawStart)
                    val endTime = normalizeTimestamp(rawEnd)

                    val textLines = lines.drop(timeLineIndex + 1)
                    val text = textLines.joinToString("\n").trim()

                    if (text.isNotBlank()) {
                        items.add(SubtitleItem(index, startTime, endTime, text))
                    }
                } else {
                    // Fallback if formatting was slightly off
                    val text = lines.drop(1).joinToString("\n").trim()
                    if (text.isNotBlank()) {
                        val startSec = items.size * 3
                        val endSec = startSec + 3
                        items.add(
                            SubtitleItem(
                                index = index,
                                startTime = formatSeconds(startSec),
                                endTime = formatSeconds(endSec),
                                text = text
                            )
                        )
                    }
                }
            }
        }
        return items
    }

    /**
     * Normalizes SRT content specifically for CapCut, VN Video Editor, and Premiere Pro.
     * Guarantees sequence numbers (1, 2, 3...) and standard timestamps (HH:MM:SS,mmm --> HH:MM:SS,mmm).
     */
    fun normalizeForCapCutAndVn(srtContent: String): String {
        if (srtContent.isBlank()) return ""
        val items = parse(srtContent)
        if (items.isEmpty()) return srtContent.trim()
        return format(items)
    }

    /**
     * Formats a list of SubtitleItems into a standard CapCut/VN-compatible SRT string.
     */
    fun format(items: List<SubtitleItem>): String {
        val sb = StringBuilder()
        items.forEachIndexed { idx, item ->
            val indexNum = idx + 1
            sb.append("$indexNum\n")
            sb.append("${normalizeTimestamp(item.startTime)} --> ${normalizeTimestamp(item.endTime)}\n")
            sb.append("${item.text}\n\n")
        }
        return sb.toString().trim()
    }

    /**
     * Ensures timestamp matches exact CapCut/VN format: HH:MM:SS,mmm (e.g., 00:00:59,000)
     */
    fun normalizeTimestamp(timeStr: String): String {
        val clean = timeStr.trim().replace('.', ',')
        
        // Match standard HH:MM:SS,mmm
        val standardRegex = Regex("^(\\d{2}):(\\d{2}):(\\d{2}),(\\d{3})$")
        if (standardRegex.matches(clean)) return clean

        // Match HH:MM:SS without milliseconds -> append ,000
        val noMsRegex = Regex("^(\\d{1,2}):(\\d{2}):(\\d{2})$")
        val noMsMatch = noMsRegex.find(clean)
        if (noMsMatch != null) {
            val (h, m, s) = noMsMatch.destructured
            return String.format("%02d:%02d:%02d,000", h.toInt(), m.toInt(), s.toInt())
        }

        // Match MM:SS without hours or ms -> 00:MM:SS,000
        val minSecRegex = Regex("^(\\d{1,2}):(\\d{2})$")
        val minSecMatch = minSecRegex.find(clean)
        if (minSecMatch != null) {
            val (m, s) = minSecMatch.destructured
            return String.format("00:%02d:%02d,000", m.toInt(), s.toInt())
        }

        // Match HH:MM:SS,m or HH:MM:SS,mm -> pad milliseconds
        val partialMsRegex = Regex("^(\\d{1,2}):(\\d{2}):(\\d{2}),(\\d{1,2})$")
        val partialMsMatch = partialMsRegex.find(clean)
        if (partialMsMatch != null) {
            val (h, m, s, ms) = partialMsMatch.destructured
            val paddedMs = ms.padEnd(3, '0')
            return String.format("%02d:%02d:%02d,%s", h.toInt(), m.toInt(), s.toInt(), paddedMs)
        }

        return clean.ifBlank { "00:00:00,000" }
    }

    /**
     * Extracts pure clean spoken text from SRT text by stripping index numbers and timestamps.
     */
    fun extractCleanText(srtContent: String): String {
        if (srtContent.isBlank()) return ""
        val parsed = parse(srtContent)
        if (parsed.isNotEmpty()) {
            return parsed.joinToString(" ") { it.text }
        }
        return srtContent
            .replace(Regex("\\d+\\r?\\n\\d{2}:\\d{2}:\\d{2}[,\\.]\\d{3}\\s*-->\\s*\\d{2}:\\d{2}:\\d{2}[,\\.]\\d{3}"), "")
            .replace(Regex("^\\d+\$", RegexOption.MULTILINE), "")
            .lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .joinToString(" ")
    }

    private fun formatSeconds(totalSeconds: Int): String {
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d:%02d,000", hours, minutes, seconds)
    }
}
