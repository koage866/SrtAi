package com.example.utils

import com.example.data.model.SubtitleItem

object SrtParser {

    /**
     * Parses raw SRT content string into a list of SubtitleItem objects.
     */
    fun parse(srtContent: String): List<SubtitleItem> {
        val items = mutableListOf<SubtitleItem>()
        if (srtContent.isBlank()) return items

        val blocks = srtContent.trim().split(Regex("\\n\\s*\\n"))
        for (block in blocks) {
            val lines = block.trim().lines()
            if (lines.size >= 2) {
                val index = lines[0].trim().toIntOrNull() ?: (items.size + 1)
                val timeLine = if (lines[1].contains("-->")) lines[1] else if (lines.size > 2 && lines[2].contains("-->")) lines[2] else ""
                
                if (timeLine.contains("-->")) {
                    val parts = timeLine.split("-->")
                    val startTime = parts.getOrNull(0)?.trim() ?: "00:00:00,000"
                    val endTime = parts.getOrNull(1)?.trim() ?: "00:00:05,000"
                    
                    val textLinesIndex = if (lines[1].contains("-->")) 2 else 3
                    val text = if (lines.size > textLinesIndex) {
                        lines.subList(textLinesIndex, lines.size).joinToString(" ")
                    } else if (lines.size > 1 && !lines[1].contains("-->")) {
                        lines.subList(1, lines.size).joinToString(" ")
                    } else {
                        ""
                    }
                    
                    if (text.isNotBlank()) {
                        items.add(SubtitleItem(index, startTime, endTime, text.trim()))
                    }
                } else {
                    // Fallback if formatting was slightly off
                    val text = lines.subList(1, lines.size).joinToString(" ")
                    if (text.isNotBlank()) {
                        val startSec = items.size * 3
                        val endSec = startSec + 3
                        items.add(
                            SubtitleItem(
                                index = index,
                                startTime = formatSeconds(startSec),
                                endTime = formatSeconds(endSec),
                                text = text.trim()
                            )
                        )
                    }
                }
            }
        }
        return items
    }

    /**
     * Formats a list of SubtitleItems into a standard SRT string.
     */
    fun format(items: List<SubtitleItem>): String {
        val sb = StringBuilder()
        items.forEachIndexed { idx, item ->
            val indexNum = idx + 1
            sb.append("$indexNum\n")
            sb.append("${item.startTime} --> ${item.endTime}\n")
            sb.append("${item.text}\n\n")
        }
        return sb.toString().trim()
    }

    /**
     * Extracts pure clean spoken text from SRT text by stripping index numbers and timestamps.
     */
    fun extractCleanText(srtContent: String): String {
        if (srtContent.isBlank()) return ""
        val parsed = parse(srtContent)
        if (parsed.isNotEmpty()) {
            return parsed.joinToString(" ") { it.text }
        }
        // Fallback regex strip if block parsing failed
        return srtContent
            .replace(Regex("\\d+\\r?\\n\\d{2}:\\d{2}:\\d{2}[,\\.]\\d{3}\\s*-->\\s*\\d{2}:\\d{2}:\\d{2}[,\\.]\\d{3}"), "")
            .replace(Regex("^\\d+\$", RegexOption.MULTILINE), "")
            .lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .joinToString(" ")
    }

    private fun formatSeconds(totalSeconds: Int): String {
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d:%02d,000", hours, minutes, seconds)
    }
}
