package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object AudioExporter {

    /**
     * Saves a WAV file to the device's public Downloads/Audio storage.
     * Returns the Uri of the exported file.
     */
    fun saveAudioToStorage(context: Context, sourceFile: File, outputFileName: String): Result<Uri> {
        return try {
            val fileName = if (outputFileName.endsWith(".wav") || outputFileName.endsWith(".mp3")) {
                outputFileName
            } else {
                "$outputFileName.wav"
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "audio/wav")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SubtitleTTS")
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    ?: return Result.failure(Exception("Failed to create MediaStore entry."))

                resolver.openOutputStream(uri)?.use { outputStream ->
                    FileInputStream(sourceFile).use { inputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }
                Result.success(uri)
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val targetDir = File(downloadsDir, "SubtitleTTS")
                if (!targetDir.exists()) {
                    targetDir.mkdirs()
                }
                val destFile = File(targetDir, fileName)
                FileInputStream(sourceFile).use { inputStream ->
                    FileOutputStream(destFile).use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }
                val fileUri = Uri.fromFile(destFile)
                Result.success(fileUri)
            }
        } catch (e: Exception) {
            Log.e("AudioExporter", "Failed to save audio file to storage", e)
            Result.failure(e)
        }
    }

    /**
     * Creates a share intent to send or share the audio file using FileProvider.
     */
    fun shareAudioFile(context: Context, audioFile: File) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, audioFile)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "Share Voiceover Audio")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e("AudioExporter", "Error launching share intent", e)
        }
    }

    /**
     * Exports raw SRT string as a standard CapCut/VN compatible file to public Downloads folder.
     */
    fun saveSrtToStorage(context: Context, rawSrtContent: String, fileName: String = "subtitles.srt"): Result<Uri> {
        return try {
            val normalizedSrt = SrtParser.normalizeForCapCutAndVn(rawSrtContent)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/x-subrip")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SubtitleTTS")
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    ?: return Result.failure(Exception("Failed to create SRT MediaStore entry."))

                resolver.openOutputStream(uri)?.use { outputStream ->
                    outputStream.write(normalizedSrt.toByteArray(Charsets.UTF_8))
                }
                Result.success(uri)
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val targetDir = File(downloadsDir, "SubtitleTTS")
                if (!targetDir.exists()) targetDir.mkdirs()
                val destFile = File(targetDir, fileName)
                destFile.writeText(normalizedSrt, Charsets.UTF_8)
                Result.success(Uri.fromFile(destFile))
            }
        } catch (e: Exception) {
            Log.e("AudioExporter", "Failed to save SRT file", e)
            Result.failure(e)
        }
    }

    /**
     * Shares SRT file directly to CapCut, VN Video Editor, or File Manager.
     */
    fun shareSrtFile(context: Context, rawSrtContent: String, fileName: String = "subtitles.srt") {
        try {
            val normalizedSrt = SrtParser.normalizeForCapCutAndVn(rawSrtContent)
            val cacheFile = File(context.cacheDir, fileName)
            cacheFile.writeText(normalizedSrt, Charsets.UTF_8)

            val authority = "${context.packageName}.fileprovider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, cacheFile)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "CapCut & VN Subtitle SRT File")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "Open / Import Subtitle in CapCut, VN...")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e("AudioExporter", "Error sharing SRT file", e)
        }
    }
}
