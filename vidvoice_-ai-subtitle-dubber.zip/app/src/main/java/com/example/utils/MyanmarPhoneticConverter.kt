package com.example.utils

/**
 * Utility to convert Myanmar (Burmese) Unicode text into pronounceable phonetics
 * for Android TTS engines when the device lacks a native Burmese TTS voice pack.
 */
object MyanmarPhoneticConverter {

    private val wordMap = mapOf(
        "မင်္ဂလာပါ" to "Min galar par",
        "သခင်မလေး" to "Thakin ma lay",
        "ဗီဒီယို" to "Video",
        "စာတန်းထိုး" to "Sar tan thoe",
        "အသံထွက်" to "Ah than htwat",
        "နားထောင်" to "Nar htaung",
        "ကြိုဆိုပါတယ်" to "Kyo tsoe par tay",
        "ကျေးဇူးတင်ပါတယ်" to "Kyay zoor tin par tay",
        "ခုလိုမျိုး" to "Khu lo myo",
        "ဖြစ်ရမှာလေ" to "hpyit ya hmar lay",
        "ရှာနေတာ" to "Shar nay tar",
        "ရက်တော်တော်ကြာပြီ" to "Yat taw taw kyar pyi",
        "သူ့ကို" to "Thu ko",
        "မဖြစ်မနေ" to "Ma hpyit ma nay",
        "ရှာရမှာလား" to "Shar ya hmar lar",
        "ရှာရမယ်" to "Shar ya myal",
        "ရှာတွေ့မှ" to "Shar twat hmah",
        "ငါ" to "Ngar",
        "ကျွန်မတို့" to "Kyun ma toe",
        "ဘယ်မှာလဲ" to "Bal hmar lay",
        "ဂူချင်းရှန်ရှန်" to "Gu chin shan shan"
    )

    private val charMap = mapOf(
        'က' to "k", 'ခ' to "kh", 'ဂ' to "g", 'ဃ' to "g", 'င' to "ng",
        'စ' to "s", 'ဆ' to "seh", 'ဇ' to "z", 'ဈ' to "z", 'ည' to "ny",
        'ဋ' to "t", 'ဌ' to "th", 'ဍ' to "d", 'ဎ' to "d", 'ဏ' to "n",
        'တ' to "t", 'ထ' to "th", 'ဒ' to "d", 'ဓ' to "d", 'န' to "n",
        'ပ' to "p", 'ဖ' to "ph", 'ဗ' to "b", 'ဘ' to "b", 'မ' to "m",
        'ယ' to "y", 'ရ' to "r", 'လ' to "l", 'ဝ' to "w", 'သ' to "th",
        'ဟ' to "h", 'ဠ' to "l", 'အ' to "a"
    )

    fun toPronounceablePhonetic(text: String): String {
        if (text.isBlank()) return ""
        
        // 1. Try whole word/phrase replacement for common Burmese phrases
        var result = text
        wordMap.forEach { (burmese, phonetic) ->
            result = result.replace(burmese, " $phonetic ")
        }

        // 2. Convert remaining Burmese Unicode characters into readable phonetic sounds
        val sb = StringBuilder()
        var i = 0
        while (i < result.length) {
            val ch = result[i]
            if (ch in '\u1000'..'\u109F') {
                val phonetic = charMap[ch] ?: ""
                if (phonetic.isNotEmpty()) {
                    sb.append(phonetic)
                }
            } else {
                sb.append(ch)
            }
            i++
        }

        val cleaned = sb.toString()
            .replace(Regex("\\s+"), " ")
            .trim()

        return if (cleaned.isNotBlank()) cleaned else text
    }
}
