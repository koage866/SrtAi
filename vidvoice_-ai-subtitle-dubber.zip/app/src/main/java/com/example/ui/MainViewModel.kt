package com.example.ui

import android.app.Application
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.VideoInfo
import com.example.data.model.VoiceGender
import com.example.data.model.VoiceProfile
import com.example.data.repository.SampleVideoData
import com.example.data.repository.SubtitleRepository
import com.example.tts.TtsManager
import com.example.utils.AudioExporter
import com.example.utils.SrtParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

data class MainUiState(
    val videoInfo: VideoInfo? = null,
    val isGeneratingSrt: Boolean = false,
    val srtStatusMessage: String = "",
    val srtText: String = "",
    val cleanSpokenText: String = "",
    val pitch: Float = VoiceProfile.PRESETS[1].pitch,
    val speechRate: Float = VoiceProfile.PRESETS[1].speechRate,
    val selectedLocale: Locale = Locale("my", "MM"),
    val availableLocales: List<Locale> = listOf(Locale("my", "MM"), Locale.US, Locale.UK, Locale.GERMANY, Locale.JAPAN),
    val voiceProfiles: List<VoiceProfile> = VoiceProfile.PRESETS,
    val selectedVoiceProfile: VoiceProfile = VoiceProfile.PRESETS[1],
    val isSpeaking: Boolean = false,
    val isSynthesizing: Boolean = false,
    val ttsStatus: String = "TTS Ready",
    val exportedAudioUri: Uri? = null,
    val exportedAudioPath: String? = null,
    val exportedSrtUri: Uri? = null,
    val userErrorMessage: String? = null,
    val snackbarMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext
    private val repository = SubtitleRepository(context)
    val ttsManager = TtsManager(context)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        // Collect TTS states
        viewModelScope.launch {
            ttsManager.isSpeaking.collect { speaking ->
                _uiState.update { it.copy(isSpeaking = speaking) }
            }
        }
        viewModelScope.launch {
            ttsManager.isSynthesizing.collect { synth ->
                _uiState.update { it.copy(isSynthesizing = synth) }
            }
        }
        viewModelScope.launch {
            ttsManager.statusMessage.collect { status ->
                _uiState.update { it.copy(ttsStatus = status) }
            }
        }
        viewModelScope.launch {
            ttsManager.availableLocales.collect { locales ->
                if (locales.isNotEmpty()) {
                    _uiState.update { it.copy(availableLocales = locales) }
                }
            }
        }

        // Load sample video by default so the user sees a ready-to-use interface
        loadSampleVideo()
    }

    fun loadSampleVideo() {
        val sample = SampleVideoData.getSampleVideoInfo()
        _uiState.update {
            it.copy(
                videoInfo = sample,
                userErrorMessage = null
            )
        }
    }

    fun selectVideo(uri: Uri) {
        viewModelScope.launch {
            try {
                var fileName = "video_clip.mp4"
                var fileSizeFormatted = "Unknown size"
                var durationFormatted = "00:00"

                // Extract file metadata
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (nameIndex != -1) fileName = cursor.getString(nameIndex) ?: fileName
                        if (sizeIndex != -1) {
                            val bytes = cursor.getLong(sizeIndex)
                            fileSizeFormatted = String.format("%.1f MB", bytes / (1024.0 * 1024.0))
                        }
                    }
                }

                // Extract duration metadata
                try {
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(context, uri)
                    val durationMsStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    retriever.release()

                    val durationMs = durationMsStr?.toLongOrNull() ?: 0L
                    val totalSec = durationMs / 1000
                    val minutes = totalSec / 60
                    val seconds = totalSec % 60
                    durationFormatted = String.format("%02d:%02d", minutes, seconds)
                } catch (e: Exception) {
                    durationFormatted = "00:30"
                }

                val info = VideoInfo(
                    uri = uri,
                    fileName = fileName,
                    durationFormatted = durationFormatted,
                    fileSizeFormatted = fileSizeFormatted,
                    isSample = false
                )

                _uiState.update {
                    it.copy(
                        videoInfo = info,
                        userErrorMessage = null,
                        snackbarMessage = "Video loaded: $fileName"
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(userErrorMessage = "Failed to load video file: ${e.message}")
                }
            }
        }
    }

    fun generateSrt() {
        val info = _uiState.value.videoInfo ?: run {
            _uiState.update { it.copy(userErrorMessage = "Please select a video file first.") }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isGeneratingSrt = true,
                    srtStatusMessage = "Analyzing video audio with Gemini AI...",
                    userErrorMessage = null
                )
            }

            val result = repository.generateSrtFromVideo(info.uri, info.isSample)
            result.fold(
                onSuccess = { rawSrt ->
                    val cleanText = SrtParser.extractCleanText(rawSrt)
                    _uiState.update {
                        it.copy(
                            isGeneratingSrt = false,
                            srtStatusMessage = "Subtitles generated successfully!",
                            srtText = rawSrt,
                            cleanSpokenText = cleanText,
                            snackbarMessage = "SRT subtitles generated successfully!"
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isGeneratingSrt = false,
                            srtStatusMessage = "",
                            userErrorMessage = error.message ?: "Failed to generate SRT subtitles."
                        )
                    }
                }
            )
        }
    }

    fun updateSrtText(newSrtText: String) {
        val cleanText = SrtParser.extractCleanText(newSrtText)
        _uiState.update {
            it.copy(
                srtText = newSrtText,
                cleanSpokenText = cleanText
            )
        }
    }

    fun updateCleanText(newCleanText: String) {
        _uiState.update {
            it.copy(cleanSpokenText = newCleanText)
        }
    }

    fun selectVoiceProfile(profile: VoiceProfile) {
        _uiState.update {
            it.copy(
                selectedVoiceProfile = profile,
                pitch = profile.pitch,
                speechRate = profile.speechRate
            )
        }
    }

    fun setPitch(pitch: Float) {
        _uiState.update { it.copy(pitch = pitch) }
    }

    fun setSpeechRate(rate: Float) {
        _uiState.update { it.copy(speechRate = rate) }
    }

    fun setLocale(locale: Locale) {
        _uiState.update { it.copy(selectedLocale = locale) }
    }

    fun playTts() {
        val text = _uiState.value.cleanSpokenText.ifBlank {
            SrtParser.extractCleanText(_uiState.value.srtText)
        }

        if (text.isBlank()) {
            _uiState.update { it.copy(userErrorMessage = "No text available for TTS playback.") }
            return
        }

        val state = _uiState.value
        ttsManager.speak(
            text = text,
            pitch = state.pitch,
            speechRate = state.speechRate,
            locale = state.selectedLocale,
            gender = state.selectedVoiceProfile.gender
        )
    }

    fun stopTts() {
        ttsManager.stop()
    }

    fun exportVoiceoverAudio() {
        val text = _uiState.value.cleanSpokenText.ifBlank {
            SrtParser.extractCleanText(_uiState.value.srtText)
        }

        if (text.isBlank()) {
            _uiState.update { it.copy(userErrorMessage = "Please generate or enter subtitle text before exporting audio.") }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isSynthesizing = true,
                    ttsStatus = "Synthesizing voiceover file...",
                    userErrorMessage = null
                )
            }

            val tempFile = File(context.cacheDir, "temp_voiceover_${System.currentTimeMillis()}.wav")
            val state = _uiState.value

            ttsManager.synthesizeToFile(
                text = text,
                outputFile = tempFile,
                pitch = state.pitch,
                speechRate = state.speechRate,
                locale = state.selectedLocale,
                gender = state.selectedVoiceProfile.gender
            ) { success, error ->
                if (success && tempFile.exists()) {
                    val exportResult = AudioExporter.saveAudioToStorage(
                        context = context,
                        sourceFile = tempFile,
                        outputFileName = "Voiceover_${System.currentTimeMillis()}"
                    )

                    exportResult.fold(
                        onSuccess = { uri ->
                            _uiState.update {
                                it.copy(
                                    isSynthesizing = false,
                                    exportedAudioUri = uri,
                                    exportedAudioPath = tempFile.absolutePath,
                                    snackbarMessage = "Audio saved to Downloads/SubtitleTTS!"
                                )
                            }
                        },
                        onFailure = { saveErr ->
                            _uiState.update {
                                it.copy(
                                    isSynthesizing = false,
                                    userErrorMessage = "Failed to save audio file: ${saveErr.message}"
                                )
                            }
                        }
                    )
                } else {
                    _uiState.update {
                        it.copy(
                            isSynthesizing = false,
                            userErrorMessage = error ?: "TTS synthesis failed."
                        )
                    }
                }
            }
        }
    }

    fun shareExportedAudio() {
        val path = _uiState.value.exportedAudioPath ?: return
        val file = File(path)
        if (file.exists()) {
            AudioExporter.shareAudioFile(context, file)
        } else {
            _uiState.update { it.copy(userErrorMessage = "Audio file not found to share.") }
        }
    }

    fun exportSrtFile() {
        val srt = _uiState.value.srtText
        if (srt.isBlank()) {
            _uiState.update { it.copy(userErrorMessage = "No SRT content to export.") }
            return
        }

        val result = AudioExporter.saveSrtToStorage(context, srt, "Subtitle_${System.currentTimeMillis()}.srt")
        result.fold(
            onSuccess = { uri ->
                _uiState.update {
                    it.copy(
                        exportedSrtUri = uri,
                        snackbarMessage = "SRT file saved to Downloads/SubtitleTTS!"
                    )
                }
            },
            onFailure = { err ->
                _uiState.update { it.copy(userErrorMessage = "Failed to export SRT: ${err.message}") }
            }
        )
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    fun clearErrorMessage() {
        _uiState.update { it.copy(userErrorMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
    }
}
