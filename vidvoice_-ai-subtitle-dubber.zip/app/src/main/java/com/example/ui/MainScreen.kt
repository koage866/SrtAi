package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.components.DownloadExportCard
import com.example.ui.components.SrtPreviewCard
import com.example.ui.components.TtsControlsCard
import com.example.ui.components.VideoPreviewCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Subtitles,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Subtitle & TTS Studio",
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Gemini AI",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(end = 4.dp)
                            )
                            Text(
                                text = "Gemini AI",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Error Banner if needed
            AnimatedVisibility(visible = uiState.userErrorMessage != null) {
                uiState.userErrorMessage?.let { err ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Error",
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Step 1: Video Input & Preview
            VideoPreviewCard(
                videoInfo = uiState.videoInfo,
                onSelectVideoUri = { uri -> viewModel.selectVideo(uri) },
                onLoadSampleVideo = { viewModel.loadSampleVideo() }
            )

            // Step 2: SRT Generation & Edit Box
            SrtPreviewCard(
                isGenerating = uiState.isGeneratingSrt,
                statusMessage = uiState.srtStatusMessage,
                srtText = uiState.srtText,
                onSrtTextChange = { viewModel.updateSrtText(it) },
                onGenerateClick = { viewModel.generateSrt() },
                onExportSrtClick = { viewModel.exportSrtFile() }
            )

            // Step 3: Text-To-Speech (TTS) Engine
            TtsControlsCard(
                cleanText = uiState.cleanSpokenText,
                onCleanTextChange = { viewModel.updateCleanText(it) },
                voiceProfiles = uiState.voiceProfiles,
                selectedVoiceProfile = uiState.selectedVoiceProfile,
                onVoiceProfileSelect = { viewModel.selectVoiceProfile(it) },
                pitch = uiState.pitch,
                onPitchChange = { viewModel.setPitch(it) },
                speechRate = uiState.speechRate,
                onSpeechRateChange = { viewModel.setSpeechRate(it) },
                selectedLocale = uiState.selectedLocale,
                availableLocales = uiState.availableLocales,
                onLocaleSelect = { viewModel.setLocale(it) },
                isSpeaking = uiState.isSpeaking,
                ttsStatus = uiState.ttsStatus,
                onPlayClick = {
                    if (uiState.isSpeaking) viewModel.stopTts() else viewModel.playTts()
                },
                onStopClick = { viewModel.stopTts() }
            )

            // Step 4: Download & Export Audio
            DownloadExportCard(
                isSynthesizing = uiState.isSynthesizing,
                exportedAudioUri = uiState.exportedAudioUri,
                cleanText = uiState.cleanSpokenText,
                onExportAudioClick = { viewModel.exportVoiceoverAudio() },
                onShareAudioClick = { viewModel.shareExportedAudio() }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
