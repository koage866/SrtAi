package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Man
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Woman
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.VoiceGender
import com.example.data.model.VoiceProfile
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TtsControlsCard(
    cleanText: String,
    onCleanTextChange: (String) -> Unit,
    voiceProfiles: List<VoiceProfile>,
    selectedVoiceProfile: VoiceProfile,
    onVoiceProfileSelect: (VoiceProfile) -> Unit,
    pitch: Float,
    onPitchChange: (Float) -> Unit,
    speechRate: Float,
    onSpeechRateChange: (Float) -> Unit,
    selectedLocale: Locale,
    availableLocales: List<Locale>,
    onLocaleSelect: (Locale) -> Unit,
    isSpeaking: Boolean,
    ttsStatus: String,
    onPlayClick: () -> Unit,
    onStopClick: () -> Unit,
    onOpenTtsSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isLocaleMenuExpanded by remember { mutableStateOf(false) }
    var selectedGenderFilter by remember { mutableStateOf<VoiceGender?>(null) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("tts_controls_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "TTS Voiceover",
                                tint = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "3. Voiceover Generator (TTS)",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Choose voice profile, pitch, and accent",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onOpenTtsSettingsClick,
                    modifier = Modifier.testTag("open_tts_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "TTS Settings",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Spoken Text Preview / Edit
            Text(
                text = "Text to be spoken by TTS:",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            OutlinedTextField(
                value = cleanText,
                onValueChange = onCleanTextChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .testTag("clean_text_field"),
                placeholder = {
                    Text("Extracted spoken text will appear here automatically...")
                },
                shape = RoundedCornerShape(12.dp),
                textStyle = MaterialTheme.typography.bodyMedium
            )

            // Voice Selector Section
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Voice Selector",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Voice Profile:",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Language / Accent dropdown
                        Box {
                            OutlinedButton(
                                onClick = { isLocaleMenuExpanded = true },
                                modifier = Modifier.testTag("voice_locale_menu_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${selectedLocale.displayLanguage} (${selectedLocale.country})",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }

                            DropdownMenu(
                                expanded = isLocaleMenuExpanded,
                                onDismissRequest = { isLocaleMenuExpanded = false }
                            ) {
                                availableLocales.forEach { locale ->
                                    DropdownMenuItem(
                                        text = { Text("${locale.displayLanguage} (${locale.country})") },
                                        onClick = {
                                            onLocaleSelect(locale)
                                            isLocaleMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Gender Filter Chips
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Filter:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        FilterChip(
                            selected = selectedGenderFilter == null,
                            onClick = { selectedGenderFilter = null },
                            label = { Text("All", style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("voice_filter_all")
                        )

                        FilterChip(
                            selected = selectedGenderFilter == VoiceGender.MALE,
                            onClick = { selectedGenderFilter = VoiceGender.MALE },
                            label = { Text("Male ♂", style = MaterialTheme.typography.labelSmall) },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Man, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            modifier = Modifier.testTag("voice_filter_male")
                        )

                        FilterChip(
                            selected = selectedGenderFilter == VoiceGender.FEMALE,
                            onClick = { selectedGenderFilter = VoiceGender.FEMALE },
                            label = { Text("Female ♀", style = MaterialTheme.typography.labelSmall) },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Woman, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            modifier = Modifier.testTag("voice_filter_female")
                        )
                    }

                    // Voice Profiles Cards Grid / Flow
                    val filteredProfiles = voiceProfiles.filter {
                        selectedGenderFilter == null || it.gender == selectedGenderFilter
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        filteredProfiles.forEach { profile ->
                            val isSelected = profile.id == selectedVoiceProfile.id
                            val genderIcon = when (profile.gender) {
                                VoiceGender.MALE -> Icons.Default.Man
                                VoiceGender.FEMALE -> Icons.Default.Woman
                                VoiceGender.NEUTRAL -> Icons.Default.Face
                            }

                            OutlinedCard(
                                onClick = { onVoiceProfileSelect(profile) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("voice_profile_${profile.id}"),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                                ),
                                colors = CardDefaults.outlinedCardColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = when (profile.gender) {
                                                VoiceGender.MALE -> MaterialTheme.colorScheme.primaryContainer
                                                VoiceGender.FEMALE -> MaterialTheme.colorScheme.secondaryContainer
                                                VoiceGender.NEUTRAL -> MaterialTheme.colorScheme.tertiaryContainer
                                            },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = genderIcon,
                                                    contentDescription = profile.gender.name,
                                                    modifier = Modifier.size(20.dp),
                                                    tint = when (profile.gender) {
                                                        VoiceGender.MALE -> MaterialTheme.colorScheme.onPrimaryContainer
                                                        VoiceGender.FEMALE -> MaterialTheme.colorScheme.onSecondaryContainer
                                                        VoiceGender.NEUTRAL -> MaterialTheme.colorScheme.onTertiaryContainer
                                                    }
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = profile.name,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                            Text(
                                                text = profile.description,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Pitch & Speed Adjustment Controls
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = "Pitch",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Pitch Fine-Tuning:",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                            Text(
                                text = "${String.format("%.2f", pitch)}x " + when {
                                    pitch < 0.85f -> "(Low / Male)"
                                    pitch > 1.15f -> "(High / Female)"
                                    else -> "(Standard)"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Quick Pitch Shortcut Buttons
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedButton(
                                onClick = { onPitchChange(0.70f) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(32.dp)
                                    .testTag("pitch_preset_deep"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Deep (0.7x)", style = MaterialTheme.typography.labelSmall)
                            }

                            OutlinedButton(
                                onClick = { onPitchChange(1.00f) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(32.dp)
                                    .testTag("pitch_preset_normal"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Normal (1.0x)", style = MaterialTheme.typography.labelSmall)
                            }

                            OutlinedButton(
                                onClick = { onPitchChange(1.25f) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(32.dp)
                                    .testTag("pitch_preset_bright"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("High (1.25x)", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        Slider(
                            value = pitch,
                            onValueChange = onPitchChange,
                            valueRange = 0.5f..1.8f,
                            steps = 12,
                            modifier = Modifier.testTag("pitch_slider")
                        )

                        // Speech Speed Adjustment
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = "Speech Speed",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Speech Speed:",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                            Text(
                                text = "${String.format("%.2f", speechRate)}x",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Slider(
                            value = speechRate,
                            onValueChange = onSpeechRateChange,
                            valueRange = 0.5f..2.0f,
                            steps = 14,
                            modifier = Modifier.testTag("speech_rate_slider")
                        )
                    }
                }
            }

            // Animated Waveform when playing
            AnimatedVisibility(visible = isSpeaking) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Playing",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = ttsStatus,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Playback Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onPlayClick,
                    enabled = cleanText.isNotBlank(),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("play_tts_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (isSpeaking) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play Voiceover"
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = if (isSpeaking) "Pause" else "Play Voiceover (အသံဖွင့်မည်)")
                }

                OutlinedButton(
                    onClick = onStopClick,
                    enabled = isSpeaking,
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("stop_tts_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop TTS")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Stop")
                }
            }
        }
    }
}
