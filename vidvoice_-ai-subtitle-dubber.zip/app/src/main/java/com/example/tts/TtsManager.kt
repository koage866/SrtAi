package com.example.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.data.model.VoiceGender
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.Locale

class TtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    
    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isSynthesizing = MutableStateFlow(false)
    val isSynthesizing: StateFlow<Boolean> = _isSynthesizing.asStateFlow()

    private val _availableLocales = MutableStateFlow<List<Locale>>(emptyList())
    val availableLocales: StateFlow<List<Locale>> = _availableLocales.asStateFlow()

    private val _statusMessage = MutableStateFlow("TTS Initializing...")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.let { ttsInstance ->
                ttsInstance.language = Locale.US
                _isInitialized.value = true
                _statusMessage.value = "TTS Ready"

                // Fetch supported locales
                val locales = mutableSetOf<Locale>()
                locales.add(Locale.US)
                locales.add(Locale.UK)
                locales.add(Locale.CANADA)
                locales.add(Locale.GERMANY)
                locales.add(Locale.FRANCE)
                locales.add(Locale.JAPAN)
                locales.add(Locale.CHINA)
                locales.add(Locale.ITALY)

                val available = locales.filter { locale ->
                    try {
                        val res = ttsInstance.isLanguageAvailable(locale)
                        res >= TextToSpeech.LANG_AVAILABLE
                    } catch (e: Exception) {
                        false
                    }
                }
                _availableLocales.value = if (available.isNotEmpty()) available else listOf(Locale.US)

                ttsInstance.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        if (utteranceId?.startsWith("synth_") == true) {
                            _isSynthesizing.value = true
                            _statusMessage.value = "Synthesizing voiceover audio..."
                        } else {
                            _isSpeaking.value = true
                            _statusMessage.value = "Playing voiceover audio..."
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        _isSynthesizing.value = false
                        _statusMessage.value = if (utteranceId?.startsWith("synth_") == true) {
                            "Voiceover synthesized successfully!"
                        } else {
                            "Playback finished."
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        _isSynthesizing.value = false
                        _statusMessage.value = "TTS Error occurred during processing."
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _isSpeaking.value = false
                        _isSynthesizing.value = false
                        _statusMessage.value = "TTS Error ($errorCode)"
                    }
                })
            }
        } else {
            _isInitialized.value = false
            _statusMessage.value = "Failed to initialize TTS engine."
        }
    }

    fun speak(
        text: String,
        pitch: Float = 1.0f,
        speechRate: Float = 1.0f,
        locale: Locale = Locale.US,
        gender: VoiceGender? = null
    ) {
        if (!_isInitialized.value || text.isBlank()) return

        tts?.let { instance ->
            instance.stop()
            instance.language = locale

            // Attempt to select matching system voice if gender provided
            if (gender != null) {
                val matchingVoice = findSystemVoice(locale, gender)
                if (matchingVoice != null) {
                    try {
                        instance.voice = matchingVoice
                    } catch (e: Exception) {
                        Log.w("TtsManager", "Could not set system voice", e)
                    }
                }
            }

            instance.setPitch(pitch)
            instance.setSpeechRate(speechRate)

            val params = Bundle()
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "speak_${System.currentTimeMillis()}")
            
            val result = instance.speak(text, TextToSpeech.QUEUE_FLUSH, params, "speak_${System.currentTimeMillis()}")
            if (result == TextToSpeech.SUCCESS) {
                _isSpeaking.value = true
            }
        }
    }

    private fun findSystemVoice(locale: Locale, gender: VoiceGender): Voice? {
        val instance = tts ?: return null
        val voices = try { instance.voices } catch (e: Exception) { null } ?: return null
        
        val localeVoices = voices.filter { it.locale.language == locale.language }
        if (localeVoices.isEmpty()) return null

        val targetKeywords = when (gender) {
            VoiceGender.MALE -> listOf("male", "guy", "man", "m-")
            VoiceGender.FEMALE -> listOf("female", "woman", "girl", "f-")
            VoiceGender.NEUTRAL -> listOf("neutral", "network", "standard")
        }

        return localeVoices.firstOrNull { voice ->
            val nameLower = voice.name.lowercase(Locale.ROOT)
            targetKeywords.any { kw -> nameLower.contains(kw) }
        } ?: localeVoices.firstOrNull()
    }


    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        _isSynthesizing.value = false
        _statusMessage.value = "Stopped."
    }

    fun synthesizeToFile(
        text: String,
        outputFile: File,
        pitch: Float = 1.0f,
        speechRate: Float = 1.0f,
        locale: Locale = Locale.US,
        gender: VoiceGender? = null,
        onComplete: (Boolean, String?) -> Unit
    ) {
        if (!_isInitialized.value || text.isBlank()) {
            onComplete(false, "TTS engine not ready or text is empty.")
            return
        }

        tts?.let { instance ->
            try {
                instance.stop()
                instance.language = locale

                if (gender != null) {
                    val matchingVoice = findSystemVoice(locale, gender)
                    if (matchingVoice != null) {
                        try {
                            instance.voice = matchingVoice
                        } catch (e: Exception) {
                            Log.w("TtsManager", "Could not set system voice", e)
                        }
                    }
                }

                instance.setPitch(pitch)
                instance.setSpeechRate(speechRate)

                val utteranceId = "synth_${System.currentTimeMillis()}"
                
                // Add temporary listener for this specific export
                val previousListener = instance.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {
                        _isSynthesizing.value = true
                        _statusMessage.value = "Generating audio file..."
                    }

                    override fun onDone(id: String?) {
                        _isSynthesizing.value = false
                        _statusMessage.value = "Audio generated successfully!"
                        if (id == utteranceId) {
                            onComplete(true, null)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        _isSynthesizing.value = false
                        _statusMessage.value = "Synthesis failed."
                        if (id == utteranceId) {
                            onComplete(false, "Synthesis failed.")
                        }
                    }

                    override fun onError(id: String?, errorCode: Int) {
                        _isSynthesizing.value = false
                        _statusMessage.value = "Synthesis failed with error code $errorCode."
                        if (id == utteranceId) {
                            onComplete(false, "Error code $errorCode")
                        }
                    }
                })

                val params = Bundle()
                params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)

                val result = instance.synthesizeToFile(text, params, outputFile, utteranceId)
                if (result != TextToSpeech.SUCCESS) {
                    _isSynthesizing.value = false
                    onComplete(false, "synthesizeToFile returned code $result")
                }
            } catch (e: Exception) {
                Log.e("TtsManager", "Error synthesizing to file", e)
                _isSynthesizing.value = false
                onComplete(false, e.localizedMessage)
            }
        } ?: onComplete(false, "TTS instance is null")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
