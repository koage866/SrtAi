package com.example.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.data.model.VoiceGender
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.Locale

class TtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    
    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isSynthesizing = MutableStateFlow(false)
    val isSynthesizing: StateFlow<Boolean> = _isSynthesizing.asStateFlow()

    private val _availableLocales = MutableStateFlow<List<Locale>>(emptyList())
    val availableLocales: StateFlow<List<Locale>> = _availableLocales.asStateFlow()

    private val _statusMessage = MutableStateFlow("TTS Initializing...")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.let { ttsInstance ->
                _isInitialized.value = true
                _statusMessage.value = "TTS Ready (အသံထွက်စနစ် အသင့်ရှိပါသည်)"

                // Fetch supported locales
                val localesToCheck = listOf(
                    Locale("my", "MM"),
                    Locale("my"),
                    Locale.getDefault(),
                    Locale.US,
                    Locale.UK,
                    Locale.CANADA,
                    Locale.GERMANY,
                    Locale.FRANCE,
                    Locale.JAPAN,
                    Locale.CHINA,
                    Locale.ITALY
                )

                val available = localesToCheck.filter { locale ->
                    try {
                        val res = ttsInstance.isLanguageAvailable(locale)
                        res >= TextToSpeech.LANG_AVAILABLE
                    } catch (e: Exception) {
                        false
                    }
                }
                _availableLocales.value = if (available.isNotEmpty()) available else listOf(Locale("my", "MM"), Locale.US)

                ttsInstance.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        if (utteranceId?.startsWith("synth_") == true) {
                            _isSynthesizing.value = true
                            _statusMessage.value = "Generating voiceover audio file..."
                        } else {
                            _isSpeaking.value = true
                            _statusMessage.value = "Playing voiceover audio (အသံထွက်နေပါသည်)..."
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        if (utteranceId?.startsWith("synth_") == true) {
                            _isSynthesizing.value = false
                            _statusMessage.value = "Voiceover synthesized successfully!"
                        } else {
                            if (utteranceId?.endsWith("_last") == true || utteranceId?.contains("_") == false) {
                                _isSpeaking.value = false
                                _statusMessage.value = "Playback finished (အသံထွက် ပြီးဆုံးပါပြီ)."
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        _isSynthesizing.value = false
                        _statusMessage.value = "TTS Error occurred during processing."
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _isSpeaking.value = false
                        _isSynthesizing.value = false
                        _statusMessage.value = "TTS Error ($errorCode). Check phone TTS settings."
                    }
                })
            }
        } else {
            _isInitialized.value = false
            _statusMessage.value = "Failed to initialize TTS engine on this phone."
        }
    }

    fun speak(
        text: String,
        pitch: Float = 1.0f,
        speechRate: Float = 1.0f,
        locale: Locale = Locale("my", "MM"),
        gender: VoiceGender? = null
    ) {
        if (!_isInitialized.value) {
            _statusMessage.value = "TTS Engine ပြင်ဆင်နေဆဲဖြစ်ပါသည်။ ခဏစောင့်ပါ။ (TTS Engine initializing...)"
            return
        }

        if (text.isBlank()) {
            _statusMessage.value = "ဖတ်ရန် စာသား မရှိပါ။ (No text to speak)"
            return
        }

        tts?.let { instance ->
            instance.stop()

            // Try requested locale
            var langResult = instance.setLanguage(locale)
            var activeLocale = locale
            var isFallback = false

            if (langResult < TextToSpeech.LANG_AVAILABLE && locale.language == "my") {
                langResult = instance.setLanguage(Locale("my"))
                if (langResult >= TextToSpeech.LANG_AVAILABLE) {
                    activeLocale = Locale("my")
                }
            }

            if (langResult < TextToSpeech.LANG_AVAILABLE) {
                // Requested language voice data missing on device; fallback gracefully
                val defaultResult = instance.setLanguage(Locale.getDefault())
                if (defaultResult >= TextToSpeech.LANG_AVAILABLE) {
                    activeLocale = Locale.getDefault()
                } else {
                    instance.setLanguage(Locale.US)
                    activeLocale = Locale.US
                }
                isFallback = true
                Log.w("TtsManager", "Requested locale $locale missing voice data. Fallback to $activeLocale")
            }

            instance.setPitch(pitch)
            instance.setSpeechRate(speechRate)

            // Attempt to select matching system voice if gender provided
            if (gender != null) {
                val matchingVoice = findSystemVoice(activeLocale, gender)
                if (matchingVoice != null) {
                    try {
                        instance.voice = matchingVoice
                    } catch (e: Exception) {
                        Log.w("TtsManager", "Could not set system voice", e)
                    }
                }
            }

            // Split text into sentences/phrases to prevent hitting max input length or TTS truncation
            val rawSentences = text.split(Regex("(?<=[။\n.!?])")).map { it.trim() }.filter { it.isNotBlank() }
            val sentences = if (rawSentences.isNotEmpty()) rawSentences else listOf(text.trim())

            val baseId = "speak_${System.currentTimeMillis()}"
            var successCount = 0

            sentences.forEachIndexed { index, sentence ->
                val params = Bundle()
                val utteranceId = if (index == sentences.lastIndex) "${baseId}_${index}_last" else "${baseId}_${index}"
                params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)

                val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                val speakResult = instance.speak(sentence, queueMode, params, utteranceId)

                if (speakResult == TextToSpeech.SUCCESS) {
                    successCount++
                }
            }

            if (successCount > 0) {
                _isSpeaking.value = true
                _statusMessage.value = if (isFallback && locale.language == "my") {
                    "သင့်ဖုန်းတွင် မြန်မာ (Burmese) TTS Voice မရှိသေးပါသဖြင့် Standard Voice ဖြင့် ထွက်ပါမည်။"
                } else {
                    "Playing voiceover audio..."
                }
            } else {
                _isSpeaking.value = false
                _statusMessage.value = "TTS speak error. Phone TTS engine returned error code."
            }
        } ?: run {
            _statusMessage.value = "TTS Engine is not available on this device."
        }
    }

    private fun findSystemVoice(locale: Locale, gender: VoiceGender): Voice? {
        val instance = tts ?: return null
        val voices = try { instance.voices } catch (e: Exception) { null } ?: return null
        
        val localeVoices = voices.filter { it.locale.language == locale.language }
        if (localeVoices.isEmpty()) return null

        val targetKeywords = when (gender) {
            VoiceGender.MALE -> listOf("male", "guy", "man", "m-")
            VoiceGender.FEMALE -> listOf("female", "woman", "girl", "f-")
            VoiceGender.NEUTRAL -> listOf("neutral", "network", "standard")
        }

        return localeVoices.firstOrNull { voice ->
            val nameLower = voice.name.lowercase(Locale.ROOT)
            targetKeywords.any { kw -> nameLower.contains(kw) }
        } ?: localeVoices.firstOrNull()
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        _isSynthesizing.value = false
        _statusMessage.value = "Stopped."
    }

    fun synthesizeToFile(
        text: String,
        outputFile: File,
        pitch: Float = 1.0f,
        speechRate: Float = 1.0f,
        locale: Locale = Locale("my", "MM"),
        gender: VoiceGender? = null,
        onComplete: (Boolean, String?) -> Unit
    ) {
        if (!_isInitialized.value || text.isBlank()) {
            onComplete(false, "TTS engine not ready or text is empty.")
            return
        }

        tts?.let { instance ->
            try {
                instance.stop()

                var langResult = instance.setLanguage(locale)
                var activeLocale = locale
                if (langResult < TextToSpeech.LANG_AVAILABLE && locale.language == "my") {
                    langResult = instance.setLanguage(Locale("my"))
                    if (langResult >= TextToSpeech.LANG_AVAILABLE) {
                        activeLocale = Locale("my")
                    }
                }

                if (langResult < TextToSpeech.LANG_AVAILABLE) {
                    val defaultResult = instance.setLanguage(Locale.getDefault())
                    if (defaultResult >= TextToSpeech.LANG_AVAILABLE) {
                        activeLocale = Locale.getDefault()
                    } else {
                        instance.setLanguage(Locale.US)
                        activeLocale = Locale.US
                    }
                }

                if (gender != null) {
                    val matchingVoice = findSystemVoice(activeLocale, gender)
                    if (matchingVoice != null) {
                        try {
                            instance.voice = matchingVoice
                        } catch (e: Exception) {
                            Log.w("TtsManager", "Could not set system voice", e)
                        }
                    }
                }

                instance.setPitch(pitch)
                instance.setSpeechRate(speechRate)

                val utteranceId = "synth_${System.currentTimeMillis()}"

                val params = Bundle()
                params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)

                instance.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {
                        _isSynthesizing.value = true
                        _statusMessage.value = "Generating audio file..."
                    }

                    override fun onDone(id: String?) {
                        _isSynthesizing.value = false
                        _statusMessage.value = "Audio generated successfully!"
                        if (id == utteranceId) {
                            onComplete(true, null)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        _isSynthesizing.value = false
                        _statusMessage.value = "Synthesis failed."
                        if (id == utteranceId) {
                            onComplete(false, "Synthesis failed.")
                        }
                    }

                    override fun onError(id: String?, errorCode: Int) {
                        _isSynthesizing.value = false
                        _statusMessage.value = "Synthesis failed with error code $errorCode."
                        if (id == utteranceId) {
                            onComplete(false, "Error code $errorCode")
                        }
                    }
                })

                val result = instance.synthesizeToFile(text, params, outputFile, utteranceId)
                if (result != TextToSpeech.SUCCESS) {
                    _isSynthesizing.value = false
                    onComplete(false, "synthesizeToFile returned code $result")
                }
            } catch (e: Exception) {
                Log.e("TtsManager", "Error synthesizing to file", e)
                _isSynthesizing.value = false
                onComplete(false, e.localizedMessage)
            }
        } ?: onComplete(false, "TTS instance is null")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
