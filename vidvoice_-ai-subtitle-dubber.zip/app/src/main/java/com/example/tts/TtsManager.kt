package com.example.tts

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.data.model.VoiceGender
import com.example.utils.MyanmarPhoneticConverter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.Locale

class TtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context, this)

    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private val _isSynthesizing = MutableStateFlow(false)
    val isSynthesizing: StateFlow<Boolean> = _isSynthesizing

    private val _statusMessage = MutableStateFlow("Initializing TTS Engine...")
    val statusMessage: StateFlow<String> = _statusMessage

    private val _availableLocales = MutableStateFlow<List<Locale>>(emptyList())
    val availableLocales: StateFlow<List<Locale>> = _availableLocales

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.let { ttsInstance ->
                _isInitialized.value = true
                _statusMessage.value = "TTS Ready (အသံထွက်စနစ် အသင့်ရှိပါသည်)"

                // Fetch supported locales
                val localesToCheck = listOf(
                    Locale("my", "MM"),
                    Locale("my"),
                    Locale.getDefault(),
                    Locale.US,
                    Locale.UK
                )

                val available = localesToCheck.filter { locale ->
                    try {
                        val res = ttsInstance.isLanguageAvailable(locale)
                        res >= TextToSpeech.LANG_AVAILABLE
                    } catch (e: Exception) {
                        false
                    }
                }
                _availableLocales.value = if (available.isNotEmpty()) available else listOf(Locale("my", "MM"), Locale.US)

                ttsInstance.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        if (utteranceId?.startsWith("synth_") == true) {
                            _isSynthesizing.value = true
                            _statusMessage.value = "Generating voiceover audio file..."
                        } else {
                            _isSpeaking.value = true
                            _statusMessage.value = "Playing voiceover audio (အသံထွက်နေပါသည်)..."
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        if (utteranceId?.startsWith("synth_") == true) {
                            _isSynthesizing.value = false
                            _statusMessage.value = "Voiceover synthesized successfully!"
                        } else {
                            if (utteranceId?.endsWith("_last") == true || utteranceId?.contains("_") == false) {
                                _isSpeaking.value = false
                                _statusMessage.value = "Playback finished (အသံထွက် ပြီးဆုံးပါပြီ)."
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        _isSynthesizing.value = false
                        _statusMessage.value = "TTS Playback Error."
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _isSpeaking.value = false
                        _isSynthesizing.value = false
                        _statusMessage.value = "TTS Error ($errorCode). Check phone TTS settings."
                    }
                })
            }
        } else {
            _isInitialized.value = false
            _statusMessage.value = "Failed to initialize TTS engine on this phone."
        }
    }

    fun speak(
        text: String,
        pitch: Float = 1.0f,
        speechRate: Float = 1.0f,
        locale: Locale = Locale("my", "MM"),
        gender: VoiceGender? = null
    ) {
        if (!_isInitialized.value) {
            _statusMessage.value = "TTS Engine ပြင်ဆင်နေဆဲဖြစ်ပါသည်။ ခဏစောင့်ပါ။ (TTS Engine initializing...)"
            return
        }

        if (text.isBlank()) {
            _statusMessage.value = "ဖတ်ရန် စာသား မရှိပါ။ (No text to speak)"
            return
        }

        tts?.let { instance ->
            instance.stop()

            // Check if native Burmese TTS data exists
            var isBurmeseSupported = false
            try {
                val checkResult = instance.isLanguageAvailable(Locale("my", "MM"))
                val checkResult2 = instance.isLanguageAvailable(Locale("my"))
                isBurmeseSupported = (checkResult >= TextToSpeech.LANG_AVAILABLE || checkResult2 >= TextToSpeech.LANG_AVAILABLE)
            } catch (e: Exception) {
                isBurmeseSupported = false
            }

            var activeLocale = locale
            val textToSpeak: String

            if (isBurmeseSupported && locale.language == "my") {
                instance.setLanguage(Locale("my", "MM"))
                textToSpeak = text
                activeLocale = Locale("my", "MM")
            } else {
                // Fallback to phonetic conversion for standard Android devices without Burmese TTS
                textToSpeak = if (containsBurmese(text)) {
                    MyanmarPhoneticConverter.toPronounceablePhonetic(text)
                } else {
                    text
                }

                val defaultRes = instance.setLanguage(Locale.US)
                if (defaultRes < TextToSpeech.LANG_AVAILABLE) {
                    instance.setLanguage(Locale.getDefault())
                    activeLocale = Locale.getDefault()
                } else {
                    activeLocale = Locale.US
                }
            }

            instance.setPitch(pitch)
            instance.setSpeechRate(speechRate)

            if (gender != null) {
                val matchingVoice = findSystemVoice(activeLocale, gender)
                if (matchingVoice != null) {
                    try {
                        instance.voice = matchingVoice
                    } catch (e: Exception) {
                        Log.w("TtsManager", "Could not set system voice", e)
                    }
                }
            }

            // Split into sentences/phrases
            val rawSentences = textToSpeak.split(Regex("(?<=[။\n.!?])")).map { it.trim() }.filter { it.isNotBlank() }
            val sentences = if (rawSentences.isNotEmpty()) rawSentences else listOf(textToSpeak.trim())

            val baseId = "speak_${System.currentTimeMillis()}"
            var successCount = 0

            sentences.forEachIndexed { index, sentence ->
                val params = Bundle()
                val utteranceId = if (index == sentences.lastIndex) "${baseId}_${index}_last" else "${baseId}_${index}"
                params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)

                val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                val speakResult = instance.speak(sentence, queueMode, params, utteranceId)

                if (speakResult == TextToSpeech.SUCCESS) {
                    successCount++
                }
            }

            if (successCount > 0) {
                _isSpeaking.value = true
                _statusMessage.value = if (!isBurmeseSupported && containsBurmese(text)) {
                    "Playing phonetic voiceover audio (အသံထွက်နေပါသည်)..."
                } else {
                    "Playing voiceover audio (အသံထွက်နေပါသည်)..."
                }
            } else {
                _isSpeaking.value = false
                _statusMessage.value = "TTS speak error. Phone TTS engine returned error code."
            }
        } ?: run {
            _statusMessage.value = "TTS Engine is not available on this device."
        }
    }

    private fun containsBurmese(text: String): Boolean {
        return text.any { it in '\u1000'..'\u109F' }
    }

    private fun findSystemVoice(locale: Locale, gender: VoiceGender): Voice? {
        val instance = tts ?: return null
        val voices = try { instance.voices } catch (e: Exception) { null } ?: return null
        
        val localeVoices = voices.filter { it.locale.language == locale.language }
        if (localeVoices.isEmpty()) return null

        val targetKeywords = when (gender) {
            VoiceGender.MALE -> listOf("male", "guy", "man", "m-")
            VoiceGender.FEMALE -> listOf("female", "woman", "girl", "f-")
            VoiceGender.NEUTRAL -> listOf("neutral", "network", "standard")
        }

        return localeVoices.firstOrNull { voice ->
            val nameLower = voice.name.lowercase(Locale.ROOT)
            targetKeywords.any { kw -> nameLower.contains(kw) }
        } ?: localeVoices.firstOrNull()
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        _isSynthesizing.value = false
        _statusMessage.value = "Stopped."
    }

    fun synthesizeToFile(
        text: String,
        outputFile: File,
        pitch: Float = 1.0f,
        speechRate: Float = 1.0f,
        locale: Locale = Locale("my", "MM"),
        gender: VoiceGender? = null,
        onComplete: (Boolean, String?) -> Unit
    ) {
        if (!_isInitialized.value || text.isBlank()) {
            onComplete(false, "TTS engine not ready or text is empty.")
            return
        }

        tts?.let { instance ->
            try {
                instance.stop()

                var isBurmeseSupported = false
                try {
                    val checkResult = instance.isLanguageAvailable(Locale("my", "MM"))
                    isBurmeseSupported = checkResult >= TextToSpeech.LANG_AVAILABLE
                } catch (e: Exception) {
                    isBurmeseSupported = false
                }

                val textToSynth = if (!isBurmeseSupported && containsBurmese(text)) {
                    MyanmarPhoneticConverter.toPronounceablePhonetic(text)
                } else {
                    text
                }

                var activeLocale = locale
                if (isBurmeseSupported) {
                    instance.setLanguage(Locale("my", "MM"))
                    activeLocale = Locale("my", "MM")
                } else {
                    instance.setLanguage(Locale.US)
                    activeLocale = Locale.US
                }

                if (gender != null) {
                    val matchingVoice = findSystemVoice(activeLocale, gender)
                    if (matchingVoice != null) {
                        try {
                            instance.voice = matchingVoice
                        } catch (e: Exception) {
                            Log.w("TtsManager", "Could not set system voice", e)
                        }
                    }
                }

                instance.setPitch(pitch)
                instance.setSpeechRate(speechRate)

                val utteranceId = "synth_${System.currentTimeMillis()}"

                val params = Bundle()
                params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)

                instance.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {
                        _isSynthesizing.value = true
                        _statusMessage.value = "Generating audio file..."
                    }

                    override fun onDone(id: String?) {
                        _isSynthesizing.value = false
                        _statusMessage.value = "Audio generated successfully!"
                        if (id == utteranceId) {
                            onComplete(true, null)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        _isSynthesizing.value = false
                        _statusMessage.value = "Synthesis failed."
                        if (id == utteranceId) {
                            onComplete(false, "Synthesis failed.")
                        }
                    }

                    override fun onError(id: String?, errorCode: Int) {
                        _isSynthesizing.value = false
                        _statusMessage.value = "Synthesis failed with error code $errorCode."
                        if (id == utteranceId) {
                            onComplete(false, "Error code $errorCode")
                        }
                    }
                })

                val result = instance.synthesizeToFile(textToSynth, params, outputFile, utteranceId)
                if (result != TextToSpeech.SUCCESS) {
                    _isSynthesizing.value = false
                    onComplete(false, "synthesizeToFile returned code $result")
                }
            } catch (e: Exception) {
                Log.e("TtsManager", "Error synthesizing to file", e)
                _isSynthesizing.value = false
                onComplete(false, e.localizedMessage)
            }
        } ?: onComplete(false, "TTS instance is null")
    }

    fun openTtsSettings(context: Context) {
        try {
            val intent = Intent("com.android.settings.TTS_SETTINGS")
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
            } catch (ex: Exception) {
                Log.e("TtsManager", "Cannot open TTS settings", ex)
            }
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
