package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ColorFilterType
import com.example.data.model.FrameOverlayStyle
import com.example.data.model.PresetConfig
import com.example.data.model.WatermarkMaskPosition
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.ZoomIn
import com.example.ui.viewmodel.VideoEditorViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PresetControlPanel(
    viewModel: VideoEditorViewModel,
    presetConfig: PresetConfig,
    modifier: Modifier = Modifier
) {
    var showAdvancedControls by remember { mutableStateOf(true) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("preset_control_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E1B2E)
        ),
        elevation = CardDefaults.cardElevation(6.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            // Big 1-Click Auto Bypass Button (Golden Cyan-Purple Gradient)
            Button(
                onClick = { viewModel.executeOneClickBypassProcessing() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("one_click_bypass_btn"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent
                ),
                contentPadding = PaddingValues()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color(0xFF06B6D4), // Cyan
                                    Color(0xFF8B5CF6), // Purple
                                    Color(0xFFEC4899)  // Pink
                                )
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "⚡ ၁-CLICK အလိုအလျောက် ဗီဒီယို ပြင်ဆင်ရန်",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Preset Selection Chips
            Text(
                text = "📌 မြန်ဆန်သော နမူနာ ပရိုဖိုင်များ (Quick Presets):",
                color = Color(0xFFD1D5DB),
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = true,
                    onClick = { viewModel.applyPresetProfile("AUTO") },
                    label = { Text("⚡ Auto Bypass (အလိုအလျောက်)", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF312E81),
                        selectedLabelColor = Color(0xFFC7D2FE)
                    )
                )

                FilterChip(
                    selected = false,
                    onClick = { viewModel.applyPresetProfile("DRAMA") },
                    label = { Text("🎬 Short Drama (ဇာတ်လမ်းတို)", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = Color(0xFF1F2937),
                        labelColor = Color(0xFFD1D5DB)
                    )
                )

                FilterChip(
                    selected = false,
                    onClick = { viewModel.applyPresetProfile("TIKTOK") },
                    label = { Text("📱 TikTok / Reels (ဗီဒီယိုတို)", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = Color(0xFF1F2937),
                        labelColor = Color(0xFFD1D5DB)
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Advanced Tuning Toggle Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showAdvancedControls = !showAdvancedControls }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = Color(0xFF06B6D4),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "စိတ်ကြိုက် အနုစိတ် ပြင်ဆင်ရန် (Custom Parameters)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                IconButton(onClick = { showAdvancedControls = !showAdvancedControls }) {
                    Icon(
                        imageVector = if (showAdvancedControls) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = Color.LightGray
                    )
                }
            }

            AnimatedVisibility(visible = showAdvancedControls) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Feature 1: 1s-3s Short Clips Split & Order Re-shuffler (Exact user request!)
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF1E293B),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.horizontalGradient(listOf(Color(0xFF38BDF8), Color(0xFF8B5CF6)))
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ContentCut,
                                    contentDescription = null,
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "✂ ၁s မှ ၃s Clip အတိုများ ဖြတ်ညှပ်ကပ် & အစီအစဉ် ပြန်စီခြင်း",
                                    color = Color(0xFF7DD3FC),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ဗီဒီယို အရှည်ကြီးကို တိုက်ရိုက် မသုံးဘဲ ၁-၃ စက္ကန့် Clip အတိုများ ဖြတ်ပြီး အစီအစဉ် (Shuffle) ပြန်စီပေးပါသည်။",
                                color = Color.LightGray,
                                fontSize = 11.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Clip အတိုများ ဖြတ်တောက်မည်:",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Switch(
                                    checked = presetConfig.enableShortClipSlicing,
                                    onCheckedChange = { viewModel.toggleShortClipSlicing() },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFF0284C7)
                                    )
                                )
                            }

                            if (presetConfig.enableShortClipSlicing) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Clip တခုလျှင် ကြာချိန်:",
                                        color = Color.LightGray,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "${String.format("%.1f", presetConfig.clipSliceDurationSeconds)} စက္ကန့်",
                                        color = Color(0xFF38BDF8),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Slider(
                                    value = presetConfig.clipSliceDurationSeconds,
                                    onValueChange = { viewModel.setClipSliceDurationSeconds(it) },
                                    valueRange = 1.0f..3.0f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color(0xFF38BDF8),
                                        activeTrackColor = Color(0xFF0284C7)
                                    )
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Shuffle,
                                            contentDescription = null,
                                            tint = Color(0xFFA855F7),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Clip အစီအစဉ် ပြန်လည် စီစဉ်မည် (Shuffle Order)",
                                            color = Color.White,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Switch(
                                        checked = presetConfig.enableClipShuffling,
                                        onCheckedChange = { viewModel.toggleClipShuffling() },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color.White,
                                            checkedTrackColor = Color(0xFF8B5CF6)
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Feature 2: Watermark / Logo Blur & Crop Overlay (Exact user request!)
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF2E1065),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.horizontalGradient(listOf(Color(0xFFEC4899), Color(0xFFF43F5E)))
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = Color(0xFFF472B6),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "🛡️ မူရင်း Logo / Watermark Blur & Crop ဖုံးကွယ်စနစ်",
                                    color = Color(0xFFF472B6),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ဗီဒီယိုပေါ်တွင် ပါရှိသော မူရင်း Logo များ၊ Platform Watermark များကို Crop သို့မဟုတ် Blur Mask ဖုံးကွယ်ပေးပါသည်။",
                                color = Color.LightGray,
                                fontSize = 11.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Watermark Blur Mask ဖွင့်မည်:",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Switch(
                                    checked = presetConfig.enableWatermarkBlurMask,
                                    onCheckedChange = { viewModel.toggleWatermarkBlurMask() },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFFEC4899)
                                    )
                                )
                            }

                            if (presetConfig.enableWatermarkBlurMask) {
                                Text(
                                    text = "📍 Watermark တည်နေရာ ရွေးချယ်ရန်:",
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    WatermarkMaskPosition.values().forEach { pos ->
                                        FilterChip(
                                            selected = presetConfig.watermarkMaskPosition == pos,
                                            onClick = { viewModel.setWatermarkMaskPosition(pos) },
                                            label = { Text(pos.displayName, fontSize = 10.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFFEC4899),
                                                selectedLabelColor = Color.White,
                                                containerColor = Color(0xFF1F2937),
                                                labelColor = Color.LightGray
                                            )
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Blur Size / Radius:",
                                        color = Color.LightGray,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "${presetConfig.watermarkBlurSizePercent.toInt()}%",
                                        color = Color(0xFFF472B6),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Slider(
                                    value = presetConfig.watermarkBlurSizePercent,
                                    onValueChange = { viewModel.setWatermarkBlurSizePercent(it) },
                                    valueRange = 10f..30f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color(0xFFEC4899),
                                        activeTrackColor = Color(0xFFBE185D)
                                    )
                                )
                            }
                        }
                    }

                    // Feature 3: Horizontal Mirror Toggle (Exact user choice)
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1F2937)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Flip,
                                    contentDescription = null,
                                    tint = Color(0xFFA855F7),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Horizontal Mirror (ဘယ်/ညာ လှည့်မည်)",
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (presetConfig.isMirrorFlipped)
                                            "✅ လက်ရှိ: ဘယ်/ညာ မာရာ ပြောင်းပြန် လှည့်ထားပါသည်"
                                        else
                                            "❌ လက်ရှိ: မူရင်း အတိုင်း မပြောင်းဘဲ ထားပါသည်",
                                        color = if (presetConfig.isMirrorFlipped) Color(0xFFA7F3D0) else Color.LightGray,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Switch(
                                checked = presetConfig.isMirrorFlipped,
                                onCheckedChange = { viewModel.toggleMirrorFlip() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF8B5CF6)
                                )
                            )
                        }
                    }

                    // Feature 4: Zoom & Crop Sliders (နီး/ဝေး Zoom)
                    Spacer(modifier = Modifier.height(6.dp))
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ZoomIn,
                                    contentDescription = null,
                                    tint = Color(0xFFF43F5E),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Crop Zoom Level (နီး/ဝေး Zoom Level):",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "${presetConfig.cropZoomPercent.toInt()}%",
                                color = Color(0xFFF43F5E),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        Slider(
                            value = presetConfig.cropZoomPercent,
                            onValueChange = { viewModel.setCropZoomPercent(it) },
                            valueRange = 0f..25f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFF43F5E),
                                activeTrackColor = Color(0xFFE11D48)
                            )
                        )
                    }

                    // 4. Top & Bottom Watermark Crop
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "✂ Top Crop (အထက် ရေစာ Logo ဖြတ်ထုတ်ရန်):",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "${presetConfig.topCropPercent.toInt()}%",
                                color = Color(0xFFFDE047),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Slider(
                            value = presetConfig.topCropPercent,
                            onValueChange = { viewModel.setTopCropPercent(it) },
                            valueRange = 0f..15f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFDE047),
                                activeTrackColor = Color(0xFFCA8A04)
                            )
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "✂ Bottom Crop (အောက် ရေစာ / Subtitle ဖြတ်ရန်):",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "${presetConfig.bottomCropPercent.toInt()}%",
                                color = Color(0xFFFDE047),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Slider(
                            value = presetConfig.bottomCropPercent,
                            onValueChange = { viewModel.setBottomCropPercent(it) },
                            valueRange = 0f..15f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFDE047),
                                activeTrackColor = Color(0xFFCA8A04)
                            )
                        )
                    }

                    // 5. Color Filter Picker
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "🎨 Color Filter Matrix (အရောင် ပြောင်းလဲခြင်း):",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ColorFilterType.values().forEach { filter ->
                            FilterChip(
                                selected = presetConfig.colorFilter == filter,
                                onClick = { viewModel.setColorFilter(filter) },
                                label = { Text(filter.displayName.split(" ").first(), fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFEC4899),
                                    selectedLabelColor = Color.White,
                                    containerColor = Color(0xFF27272A),
                                    labelColor = Color.LightGray
                                )
                            )
                        }
                    }

                    // 6. Frame Overlay Style
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "🖼 Frame Overlay Style (နောက်ခံ ဘောင် ပုံစံ):",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FrameOverlayStyle.values().forEach { style ->
                            FilterChip(
                                selected = presetConfig.frameOverlayStyle == style,
                                onClick = { viewModel.setFrameStyle(style) },
                                label = { Text(style.displayName.split(" ").first(), fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF06B6D4),
                                    selectedLabelColor = Color.White,
                                    containerColor = Color(0xFF27272A),
                                    labelColor = Color.LightGray
                                )
                            )
                        }
                    }

                    // Custom Overlay Text Input field
                    if (presetConfig.frameOverlayStyle == FrameOverlayStyle.CUSTOM_TEXT ||
                        presetConfig.frameOverlayStyle == FrameOverlayStyle.NEWS_LOWER_THIRD ||
                        presetConfig.frameOverlayStyle == FrameOverlayStyle.CINEMATIC_BOX
                    ) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = presetConfig.customOverlayText,
                            onValueChange = { viewModel.setOverlayText(it) },
                            label = { Text("ဘောင်ပေါ်တွင် ပြသမည့် စာတန်း (Custom Overlay Text)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF06B6D4),
                                unfocusedBorderColor = Color.Gray,
                                focusedLabelColor = Color(0xFF06B6D4)
                            ),
                            singleLine = true
                        )
                    }

                    // 7. Audio Pitch Shift
                    Spacer(modifier = Modifier.height(10.dp))
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    tint = Color(0xFF4ADE80),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Audio Pitch Shift (အသံ အနိမ့်အမြင့် ပြောင်းခြင်း):",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Text(
                                text = "+${String.format("%.1f", presetConfig.audioPitchShift)} st",
                                color = Color(0xFF4ADE80),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Slider(
                            value = presetConfig.audioPitchShift,
                            onValueChange = { viewModel.setAudioPitch(it) },
                            valueRange = 0.0f..1.5f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF4ADE80),
                                activeTrackColor = Color(0xFF16A34A)
                            )
                        )
                    }
                }
            }
        }
    }
}

// PaddingValues helper for Compose
@Composable
private fun PaddingValues() = androidx.compose.foundation.layout.PaddingValues(0.dp)
