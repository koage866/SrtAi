package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.ColorFilterType
import com.example.data.model.FrameOverlayStyle
import com.example.data.model.PresetConfig
import com.example.data.model.ProcessedVideoRecord
import com.example.data.model.VideoItem
import com.example.data.repository.VideoRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

class VideoEditorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: VideoRepository
    
    val sampleVideos: List<VideoItem>
    
    private val _selectedVideo = MutableStateFlow<VideoItem>(
        VideoItem(
            id = "sample_drama_1",
            title = "KOR Short Drama Ep.1 (တရုတ်/ကိုရီးယား ဇာတ်လမ်းတို)",
            uriPath = null,
            durationSeconds = 48,
            resolution = "1080x1920 (Vertical 9:16)",
            watermarkInfo = "Detected: KOR short drama tag (Top Right) & Xiaohongshu ID (Bottom Left)"
        )
    )
    val selectedVideo: StateFlow<VideoItem> = _selectedVideo.asStateFlow()

    private val _presetConfig = MutableStateFlow(PresetConfig.DEFAULT_AUTO_BYPASS)
    val presetConfig: StateFlow<PresetConfig> = _presetConfig.asStateFlow()

    // Processing status
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _processingProgress = MutableStateFlow(0f)
    val processingProgress: StateFlow<Float> = _processingProgress.asStateFlow()

    private val _processingStatusText = MutableStateFlow("")
    val processingStatusText: StateFlow<String> = _processingStatusText.asStateFlow()

    private val _fingerprintUniquenessScore = MutableStateFlow(0f)
    val fingerprintUniquenessScore: StateFlow<Float> = _fingerprintUniquenessScore.asStateFlow()

    private val _showProcessCompleteDialog = MutableStateFlow(false)
    val showProcessCompleteDialog: StateFlow<Boolean> = _showProcessCompleteDialog.asStateFlow()

    private val _lastProcessedRecord = MutableStateFlow<ProcessedVideoRecord?>(null)
    val lastProcessedRecord: StateFlow<ProcessedVideoRecord?> = _lastProcessedRecord.asStateFlow()

    // AI Captioning state
    private val _isAiGenerating = MutableStateFlow(false)
    val isAiGenerating: StateFlow<Boolean> = _isAiGenerating.asStateFlow()

    private val _aiCaptions = MutableStateFlow<List<String>>(
        listOf(
            "🔥 ရှာဖွေတွေ့ရှိလိုက်ပြီဖြစ်တဲ့ ဝှက်ထားသော စွမ်းအားရှင် မင်းသမီး (အခန်း ၁)",
            "⚡ တစ်ခါမှ မမြင်ဖူးသေးတဲ့ စိတ်လှုပ်ရှားဖွယ် ဇာတ်လမ်းတို မြန်မာစာတန်းထိုး",
            "🎬 မင်းသမီးရဲ့ လျှို့ဝှက်ချက်က ဘာများဖြစ်မလဲ? (အပိုင်း ၁)",
            "💥 2026 ရေပန်းစား ဇာတ်လမ်းတို - တိုက်ခိုက်ရေးနှင့် ချစ်ခြင်းမေတ္တာ"
        )
    )
    val aiCaptions: StateFlow<List<String>> = _aiCaptions.asStateFlow()

    val historyRecords: StateFlow<List<ProcessedVideoRecord>>

    init {
        val database = AppDatabase.getDatabase(application)
        repository = VideoRepository(database.videoRecordDao())
        sampleVideos = repository.getSampleVideos()
        _selectedVideo.value = sampleVideos.first()
        
        historyRecords = repository.allProcessedRecords.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun selectVideo(video: VideoItem) {
        _selectedVideo.value = video
    }

    fun updateVideoUri(uriString: String, title: String) {
        _selectedVideo.value = VideoItem(
            id = "custom_" + System.currentTimeMillis(),
            title = title,
            uriPath = uriString,
            durationSeconds = 60,
            resolution = "Original Resolution",
            watermarkInfo = "Custom Video Loaded from Gallery"
        )
    }

    // Apply Preset Profiles
    fun applyPresetProfile(presetName: String) {
        when (presetName) {
            "AUTO" -> _presetConfig.value = PresetConfig.DEFAULT_AUTO_BYPASS
            "DRAMA" -> _presetConfig.value = PresetConfig.DRAMA_PRESET
            "TIKTOK" -> _presetConfig.value = PresetConfig.TIKTOK_PRESET
        }
    }

    // Manual config updates
    fun toggleMirrorFlip() {
        _presetConfig.value = _presetConfig.value.copy(
            isMirrorFlipped = !_presetConfig.value.isMirrorFlipped
        )
    }

    fun setSpeedMultiplier(speed: Float) {
        _presetConfig.value = _presetConfig.value.copy(speedMultiplier = speed)
    }

    fun setCropZoomPercent(crop: Float) {
        _presetConfig.value = _presetConfig.value.copy(cropZoomPercent = crop)
    }

    fun setTopCropPercent(crop: Float) {
        _presetConfig.value = _presetConfig.value.copy(topCropPercent = crop)
    }

    fun setBottomCropPercent(crop: Float) {
        _presetConfig.value = _presetConfig.value.copy(bottomCropPercent = crop)
    }

    fun setColorFilter(filter: ColorFilterType) {
        _presetConfig.value = _presetConfig.value.copy(colorFilter = filter)
    }

    fun setFrameStyle(style: FrameOverlayStyle) {
        _presetConfig.value = _presetConfig.value.copy(frameOverlayStyle = style)
    }

    fun setOverlayText(text: String) {
        _presetConfig.value = _presetConfig.value.copy(customOverlayText = text)
    }

    fun setAudioPitch(pitch: Float) {
        _presetConfig.value = _presetConfig.value.copy(audioPitchShift = pitch)
    }

    // 1-Click Auto Bypass Video Processing Function
    fun executeOneClickBypassProcessing() {
        viewModelScope.launch {
            _isProcessing.value = true
            _processingProgress.value = 0f
            _processingStatusText.value = "1-Click အလိုအလျောက် ဝည်းဖြတ်ခြင်း စတင်နေသည်..."
            
            val totalFrames = 120
            val config = _presetConfig.value
            
            for (frame in 1..totalFrames) {
                delay(25)
                val progress = frame.toFloat() / totalFrames.toFloat()
                _processingProgress.value = progress
                
                when {
                    progress < 0.2f -> _processingStatusText.value = "၁။ ဗီဒီယို ဘယ်/ညာ ပြောင်းပြန်လှည့်ခြင်း (Horizontal Mirroring)..."
                    progress < 0.4f -> _processingStatusText.value = "၂။ ရေစာ (Watermark Logo) များ ဖြတ်ထုတ်ခြင်းနှင့် Zoom ချဲ့ခြင်း..."
                    progress < 0.6f -> _processingStatusText.value = "၃။ Video Speed (1.05x) နှင့် Audio Pitch ပြောင်းလဲခြင်း..."
                    progress < 0.8f -> _processingStatusText.value = "၄။ ရောင်စုံ စိစစ်စနစ် (Color Filter Matrix & Contrast) အသုံးချခြင်း..."
                    else -> _processingStatusText.value = "၅။ အသစ်စက်စက် Fingerprint Metadata Hash ထုတ်လုပ်ခြင်း..."
                }
            }

            // Calculate Uniqueness Score based on applied changes
            var score = 80.0f
            if (config.isMirrorFlipped) score += 5f
            if (config.cropZoomPercent > 3f) score += 4f
            if (config.topCropPercent > 3f) score += 3f
            if (config.bottomCropPercent > 3f) score += 3f
            if (config.colorFilter != ColorFilterType.NONE) score += 2.5f
            if (config.frameOverlayStyle != FrameOverlayStyle.NONE) score += 2f
            score = score.coerceAtMost(99.8f)

            _fingerprintUniquenessScore.value = score

            val record = ProcessedVideoRecord(
                originalTitle = _selectedVideo.value.title,
                processedFileName = "Bypassed_${System.currentTimeMillis().toString().takeLast(6)}.mp4",
                fingerprintScore = score,
                presetAppliedSummary = "Mirror: Yes | Speed: ${config.speedMultiplier}x | Zoom: ${config.cropZoomPercent.toInt()}% | Color: ${config.colorFilter.displayName.split(" ").first()}",
                videoUriPath = _selectedVideo.value.uriPath
            )

            repository.saveProcessedRecord(record)
            _lastProcessedRecord.value = record
            _isProcessing.value = false
            _showProcessCompleteDialog.value = true
        }
    }

    fun dismissCompleteDialog() {
        _showProcessCompleteDialog.value = false
    }

    fun generateBurmeseAiCaptions(promptCategory: String) {
        viewModelScope.launch {
            _isAiGenerating.value = true
            delay(1200) // Simulation
            
            val newCaptions = when (promptCategory) {
                "DRAMA" -> listOf(
                    "🔥 [အခန်း ၁] ရှာဖွေတွေ့ရှိလိုက်ပြီဖြစ်တဲ့ မင်းသမီး၏ စွမ်းအား",
                    "⚡ ပရိသတ်အကြိုက်တွေ့စေမည့် ဇာတ်လမ်းတို မြန်မာစာတန်းထိုး",
                    "🎬 ဘာကြောင့်မို့လို့ ရှာဖွေနေကြတာလဲ? လျှို့ဝှက်ချက် ထုတ်ဖော်ပြီ",
                    "💥 2026 ရေပန်းစား Drama Clip - အပိုင်း ၁"
                )
                "REACTION" -> listOf(
                    "😱 ဒီလိုမျိုး ဖြစ်သွားလိမ့်မယ်လို့ ထင်မထားခဲ့ဘူး!",
                    "🤯 အဆုံးထိ ကြည့်ဖြစ်အောင် ကြည့်လိုက်ပါဦးနော်",
                    "👇 သင်ရောဆိုရင် ဘာလုပ်မလဲ? ကွန်မန့်မှာ ပြောခဲ့ပါဦး",
                    "✨ ခံစားချက်ပါပါနဲ့ တိုက်ခိုက်ခန်းများ"
                )
                else -> listOf(
                    "✨ ဇာတ်လမ်းတို အကောင်းဆုံး အပိုင်းတိုများ",
                    "🌟 ကြည့်ရှုသူသန်းပေါင်းများစွာ သဘောကျခဲ့သော ဗီဒီယို",
                    "🔥 တရုတ်/ကိုရီးယား ဇာတ်လမ်းတို မြန်မာစာတန်းထိုး",
                    "📌 Follow နှင့် Like ပေးထားဖို့ မမေ့နဲ့နော်"
                )
            }
            _aiCaptions.value = newCaptions
            _isAiGenerating.value = false
        }
    }

    fun deleteHistoryRecord(id: Int) {
        viewModelScope.launch {
            repository.deleteRecord(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }
}
