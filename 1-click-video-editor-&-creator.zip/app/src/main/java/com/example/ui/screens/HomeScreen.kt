package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AiCaptionGeneratorSheet
import com.example.ui.components.CopyrightGuideDialog
import com.example.ui.components.HistoryListCard
import com.example.ui.components.PresetControlPanel
import com.example.ui.components.ProcessingDialog
import com.example.ui.components.VideoCanvasPreview
import com.example.ui.viewmodel.VideoEditorViewModel

enum class MainTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    EDITOR("1-Click ပြင်ရန်", Icons.Default.AutoAwesome),
    GUIDE("နည်းလမ်းများ", Icons.Default.VerifiedUser),
    CAPTIONS("AI စာတန်းထိုး", Icons.Default.Psychology),
    HISTORY("မှတ်တမ်း", Icons.Default.History)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: VideoEditorViewModel
) {
    var selectedTab by remember { mutableStateOf(MainTab.EDITOR) }
    var showGuideDialog by remember { mutableStateOf(false) }

    val selectedVideo by viewModel.selectedVideo.collectAsState()
    val presetConfig by viewModel.presetConfig.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val processingProgress by viewModel.processingProgress.collectAsState()
    val processingStatusText by viewModel.processingStatusText.collectAsState()
    val uniquenessScore by viewModel.fingerprintUniquenessScore.collectAsState()
    val showCompleteDialog by viewModel.showProcessCompleteDialog.collectAsState()
    val lastRecord by viewModel.lastProcessedRecord.collectAsState()
    val historyRecords by viewModel.historyRecords.collectAsState()

    val context = LocalContext.current
    val customGalleryVideos by viewModel.customGalleryVideos.collectAsState()

    // Activity launcher for selecting custom video from gallery
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            viewModel.updateVideoFromGallery(context, uri)
            Toast.makeText(
                context,
                "✅ Gallery မှ ဗီဒီယို ဖိုင် အောင်မြင်စွာ ရောက်ရှိပါပြီ!",
                Toast.LENGTH_LONG
            ).show()
        } else {
            Toast.makeText(
                context,
                "⚠️ Gallery မှ ဗီဒီယို ရွေးချယ်မှု မပြုလုပ်ခဲ့ပါ (မရောက်ရှိပါ)",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFF0F0D15),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF06B6D4), Color(0xFF8B5CF6))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "1-Click Video Editor",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "ဗီဒီယို မူပိုင်ခွင့်လွတ် ပြင်ဆင်စနစ်",
                                color = Color(0xFF06B6D4),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showGuideDialog = true },
                        modifier = Modifier.testTag("open_guide_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Guide",
                            tint = Color(0xFF38BDF8)
                        )
                    }

                    IconButton(
                        onClick = { videoPickerLauncher.launch("video/*") },
                        modifier = Modifier.testTag("pick_video_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Pick Video",
                            tint = Color(0xFFEC4899)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF13111C)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF13111C),
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                MainTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = {
                            selectedTab = tab
                            if (tab == MainTab.GUIDE) {
                                showGuideDialog = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color(0xFF06B6D4),
                            indicatorColor = Color(0xFF8B5CF6).copy(alpha = 0.5f),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
        ) {
            // 1. Gallery Video Arrival Status Banner (ရောက်/မရောက် ရှင်းလင်းစွာ ပြသသည့် Banner)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .testTag("gallery_status_banner"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedVideo.uriPath != null) Color(0xFF064E3B) else Color(0xFF1E1B4B)
                ),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(
                        if (selectedVideo.uriPath != null)
                            listOf(Color(0xFF10B981), Color(0xFF059669))
                        else
                            listOf(Color(0xFF6366F1), Color(0xFF8B5CF6))
                    )
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (selectedVideo.uriPath != null) Color(0xFF10B981) else Color(0xFF6366F1)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (selectedVideo.uriPath != null) Icons.Default.CheckCircle else Icons.Default.Info,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = if (selectedVideo.uriPath != null)
                                        "✅ GALLERY ဗီဒီယို ဖိုင် ရောက်ရှိပါပြီ!"
                                    else
                                        "ℹ️ GALLERY ဗီဒီယို မရောက်သေးပါ",
                                    color = if (selectedVideo.uriPath != null) Color(0xFF6EE7B7) else Color(0xFFA5B4FC),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = if (selectedVideo.uriPath != null)
                                        selectedVideo.title
                                    else
                                        "လက်ရှိတွင် နမူနာ (Sample) ဗီဒီယို စမ်းသပ်နေပါသည်",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = { videoPickerLauncher.launch("video/*") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedVideo.uriPath != null) Color(0xFF059669) else Color(0xFFEC4899)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (selectedVideo.uriPath != null) "တခြားဖိုင်ယူမည်" else "Gallery ဖွင့်မည်",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (selectedVideo.uriPath != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = Color.Black.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🔗 Uri Path: ${selectedVideo.uriPath}",
                                    color = Color(0xFFA7F3D0),
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // Video Selector Chips (Gallery Videos + Sample Videos)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .testTag("video_selector_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF191624))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VideoLibrary,
                                contentDescription = null,
                                tint = Color(0xFFA855F7),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ပြင်ဆင်မည့် ဗီဒီယို ရွေးချယ်ပါ (Video Source):",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFEC4899).copy(alpha = 0.2f),
                            modifier = Modifier.clickable { videoPickerLauncher.launch("video/*") }
                        ) {
                            Text(
                                text = "+ Gallery မှယူမည်",
                                color = Color(0xFFF472B6),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // 1. List imported Gallery Videos first if available
                    customGalleryVideos.forEach { galleryVideo ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedVideo.id == galleryVideo.id) Color(0xFF065F46) else Color(0xFF1F2937),
                            border = if (selectedVideo.id == galleryVideo.id) CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.horizontalGradient(listOf(Color(0xFF10B981), Color(0xFF059669)))
                            ) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable { viewModel.selectVideo(galleryVideo) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(10.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF34D399),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            color = Color(0xFF10B981),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "GALLERY",
                                                color = Color.White,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = galleryVideo.title,
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Text(
                                        text = galleryVideo.watermarkInfo,
                                        color = Color(0xFFA7F3D0),
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }
                    }

                    // 2. List sample videos
                    viewModel.sampleVideos.forEach { sample ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedVideo.id == sample.id) Color(0xFF312E81) else Color(0xFF27272A),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable { viewModel.selectVideo(sample) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(10.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Movie,
                                    contentDescription = null,
                                    tint = if (selectedVideo.id == sample.id) Color(0xFF38BDF8) else Color.Gray,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = sample.title,
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = sample.watermarkInfo,
                                        color = Color.LightGray,
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Main Editor Section
            when (selectedTab) {
                MainTab.EDITOR, MainTab.GUIDE -> {
                    // Live Transformed Canvas Preview
                    VideoCanvasPreview(
                        video = selectedVideo,
                        presetConfig = presetConfig,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 1-Click Auto Bypass Preset Control Panel
                    PresetControlPanel(
                        viewModel = viewModel,
                        presetConfig = presetConfig,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // AI Caption generator embedded inside editor
                    AiCaptionGeneratorSheet(
                        viewModel = viewModel,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                MainTab.CAPTIONS -> {
                    VideoCanvasPreview(
                        video = selectedVideo,
                        presetConfig = presetConfig,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    AiCaptionGeneratorSheet(
                        viewModel = viewModel,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                MainTab.HISTORY -> {
                    HistoryListCard(
                        viewModel = viewModel,
                        records = historyRecords,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }

    // Modal Dialogs
    ProcessingDialog(
        isProcessing = isProcessing,
        progress = processingProgress,
        statusText = processingStatusText,
        uniquenessScore = uniquenessScore,
        showCompleteDialog = showCompleteDialog,
        record = lastRecord,
        onDismiss = { viewModel.dismissCompleteDialog() }
    )

    if (showGuideDialog) {
        CopyrightGuideDialog(
            onDismiss = { showGuideDialog = false }
        )
    }
}
