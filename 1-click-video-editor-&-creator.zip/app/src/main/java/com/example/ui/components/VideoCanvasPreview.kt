package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ColorFilterType
import com.example.data.model.FrameOverlayStyle
import com.example.data.model.PresetConfig
import com.example.data.model.VideoItem

@Composable
fun VideoCanvasPreview(
    video: VideoItem,
    presetConfig: PresetConfig,
    modifier: Modifier = Modifier
) {
    // Animation progress for simulated video movement
    val animProgress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(4000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            )
        )
    }

    // Color matrix filter setup
    val colorMatrix = remember(presetConfig.colorFilter) {
        when (presetConfig.colorFilter) {
            ColorFilterType.NONE -> ColorMatrix()
            ColorFilterType.VIBRANT_DRAMA -> ColorMatrix().apply {
                setToSaturation(1.35f)
            }
            ColorFilterType.WARM_SUNSET -> ColorMatrix(
                floatArrayOf(
                    1.2f, 0.1f, 0f, 0f, 10f,
                    0.1f, 1.1f, 0f, 0f, 5f,
                    0f, 0.1f, 0.9f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            ColorFilterType.DARK_CINEMATIC -> ColorMatrix(
                floatArrayOf(
                    0.9f, 0.1f, 0.1f, 0f, -10f,
                    0.1f, 0.95f, 0.1f, 0f, -10f,
                    0.1f, 0.2f, 1.1f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            ColorFilterType.HIGH_CONTRAST -> ColorMatrix().apply {
                setToSaturation(1.5f)
            }
            ColorFilterType.VINTAGE_NOSTALGIA -> ColorMatrix(
                floatArrayOf(
                    0.9f, 0.2f, 0.1f, 0f, 15f,
                    0.1f, 0.8f, 0.1f, 0f, 15f,
                    0.1f, 0.1f, 0.7f, 0f, 10f,
                    0.0f, 0.0f, 0.0f, 1.0f, 0f
                )
            )
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("video_canvas_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF13111C)
        ),
        elevation = CardDefaults.cardElevation(8.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Movie,
                    contentDescription = null,
                    tint = Color(0xFF06B6D4),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = video.title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF8B5CF6).copy(alpha = 0.2f),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))))
                ) {
                    Text(
                        text = "LIVE PREVIEW",
                        color = Color(0xFFE9D5FF),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Main Video Screen Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(9f / 16f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black)
                    .border(1.dp, Color(0xFF2D2942), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Background Layer (Blur Canvas / Frame Overlay)
                if (presetConfig.frameOverlayStyle == FrameOverlayStyle.BLUR_CANVAS) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xFF2D124D), Color(0xFF111827), Color(0xFF4C1D95))
                                )
                            )
                    )
                } else if (presetConfig.frameOverlayStyle == FrameOverlayStyle.GRADIENT_BORDER) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.sweepGradient(
                                    listOf(Color(0xFFEC4899), Color(0xFF8B5CF6), Color(0xFF06B6D4), Color(0xFFEC4899))
                                )
                            )
                            .padding(8.dp)
                            .background(Color.Black)
                    )
                }

                // Inner Video Canvas Content (Simulating Video Frame with Transformations)
                val zoomRatio = 1f + (presetConfig.cropZoomPercent / 100f)
                val mirrorScale = if (presetConfig.isMirrorFlipped) -1f else 1f

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            top = (presetConfig.topCropPercent * 2.5f).dp,
                            bottom = (presetConfig.bottomCropPercent * 2.5f).dp
                        )
                        .graphicsLayer {
                            scaleX = mirrorScale * zoomRatio
                            scaleY = zoomRatio
                        }
                ) {
                    // Simulated Animated Video Frames (Forest, Martial Arts Warrior, Chinese/KOR drama characters)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val width = size.width
                        val height = size.height
                        val progress = animProgress.value

                        // Forest Background (Trees & Greenery)
                        drawRect(
                            brush = Brush.verticalGradient(
                                listOf(Color(0xFF1A382B), Color(0xFF2F5233), Color(0xFF1B2A1C))
                            ),
                            size = size
                        )

                        // Waterfall in background (Simulating user's short drama scene)
                        val xWater = width * 0.65f
                        drawRect(
                            brush = Brush.verticalGradient(
                                listOf(Color(0xFFE0F2FE), Color(0xFF38BDF8), Color(0xFF0284C7))
                            ),
                            topLeft = Offset(xWater, height * 0.15f),
                            size = Size(width * 0.25f, height * 0.45f)
                        )

                        // Rocks & Mountain paths
                        drawCircle(
                            color = Color(0xFF3F3F46),
                            radius = width * 0.35f,
                            center = Offset(width * 0.2f, height * 0.65f)
                        )

                        // Female Warrior Character (Grey Uniform, Black Boots)
                        val charX = width * 0.45f + (progress * 10f)
                        val charY = height * 0.5f

                        // Head & Hair
                        drawCircle(
                            color = Color(0xFFFDE047), // Skin tone
                            radius = width * 0.08f,
                            center = Offset(charX, charY - height * 0.18f)
                        )
                        drawCircle(
                            color = Color(0xFF18181B), // Hair ponytail
                            radius = width * 0.09f,
                            center = Offset(charX - width * 0.02f, charY - height * 0.2f)
                        )

                        // Warrior Jacket (Grey military jacket)
                        drawRect(
                            color = Color(0xFF6B7280),
                            topLeft = Offset(charX - width * 0.12f, charY - height * 0.1f),
                            size = Size(width * 0.24f, height * 0.18f)
                        )
                        // Belt & Shoulder Badges
                        drawRect(
                            color = Color(0xFF18181B),
                            topLeft = Offset(charX - width * 0.13f, charY + height * 0.03f),
                            size = Size(width * 0.26f, height * 0.03f)
                        )

                        // Leather Shorts & Legs
                        drawRect(
                            color = Color(0xFF09090B),
                            topLeft = Offset(charX - width * 0.11f, charY + height * 0.06f),
                            size = Size(width * 0.22f, height * 0.22f)
                        )

                        // Subtitle Overlay Simulation inside Video Frame
                        val textBgY = height * 0.78f
                        drawRect(
                            color = Color.Black.copy(alpha = 0.6f),
                            topLeft = Offset(width * 0.1f, textBgY),
                            size = Size(width * 0.8f, height * 0.08f)
                        )
                    }

                    // Simulated Chinese/KOR Subtitle Text inside video
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 30.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.75f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "古青上仙到底在哪里？",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Simulated Xiaohongshu / KOR Watermarks (Top Right & Bottom Left)
                    // (Top Crop / Bottom Crop will hide these when applied!)
                    if (presetConfig.topCropPercent < 4f) {
                        Surface(
                            color = Color.Red.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 10.dp, end = 10.dp)
                        ) {
                            Text(
                                text = "KOR 短剧",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (presetConfig.bottomCropPercent < 4f) {
                        Surface(
                            color = Color(0xFFFF2442), // Xiaohongshu Red
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(bottom = 12.dp, start = 10.dp)
                        ) {
                            Text(
                                text = "小红书 ID: 55284",
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Apply Color Filter Tint Layer over video content
                    if (presetConfig.colorFilter != ColorFilterType.NONE) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    when (presetConfig.colorFilter) {
                                        ColorFilterType.VIBRANT_DRAMA -> Color(0x11EC4899)
                                        ColorFilterType.WARM_SUNSET -> Color(0x1FF59E0B)
                                        ColorFilterType.DARK_CINEMATIC -> Color(0x221E1B4B)
                                        ColorFilterType.HIGH_CONTRAST -> Color(0x11000000)
                                        ColorFilterType.VINTAGE_NOSTALGIA -> Color(0x1AD97706)
                                        else -> Color.Transparent
                                    }
                                )
                        )
                    }
                }

                // Top & Bottom Crop Indication Overlay Lines
                if (presetConfig.topCropPercent > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height((presetConfig.topCropPercent * 2.5f).dp)
                            .background(Color.Red.copy(alpha = 0.35f))
                            .align(Alignment.TopCenter),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "✂ WATERMARK CROPPED (${presetConfig.topCropPercent.toInt()}%)",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (presetConfig.bottomCropPercent > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height((presetConfig.bottomCropPercent * 2.5f).dp)
                            .background(Color.Red.copy(alpha = 0.35f))
                            .align(Alignment.BottomCenter),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "✂ BOTTOM LOGO CROPPED (${presetConfig.bottomCropPercent.toInt()}%)",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Cinematic Letterbox / Custom Text Frame Overlay
                if (presetConfig.frameOverlayStyle == FrameOverlayStyle.CINEMATIC_BOX ||
                    presetConfig.frameOverlayStyle == FrameOverlayStyle.CUSTOM_TEXT ||
                    presetConfig.frameOverlayStyle == FrameOverlayStyle.NEWS_LOWER_THIRD
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color(0xEE09090B))
                                )
                            )
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = presetConfig.customOverlayText,
                            color = Color(0xFFFDE047), // Bright Yellow subtitle frame
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Mirror Flip Indicator Chip in Corner
                if (presetConfig.isMirrorFlipped) {
                    Surface(
                        color = Color(0xFF06B6D4).copy(alpha = 0.9f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Flip,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "MIRRORED (ဘယ်/ညာ)",
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Applied Parameters Summary Pill Bar
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1E1B4B),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoFixHigh,
                            contentDescription = null,
                            tint = Color(0xFFA855F7),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Speed: ${presetConfig.speedMultiplier}x | Pitch: +${presetConfig.audioPitchShift}st | Color: ${presetConfig.colorFilter.displayName.split(" ").first()}",
                            color = Color(0xFFD8B4FE),
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
