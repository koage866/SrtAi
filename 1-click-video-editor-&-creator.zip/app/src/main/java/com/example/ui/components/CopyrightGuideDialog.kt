package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
fun CopyrightGuideDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("copyright_guide_modal"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B2E)),
            elevation = CardDefaults.cardElevation(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                // Title header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF8B5CF6).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = Color(0xFFA855F7),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ဗီဒီယို မူပိုင်ခွင့်လွတ် နည်းလမ်းများ",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Video Anti-Copyright Guide & Tools",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = null,
                            tint = Color.Gray
                        )
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp),
                    color = Color(0xFF2D2942)
                )

                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Introduction Card
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF312E81).copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = null,
                                tint = Color(0xFFFDE047),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Short Drama (တရုတ်/ကိုရီးယား ဇာတ်လမ်းတိုများ) နှင့် TikTok / Reels ဗီဒီယိုများ Re-upload တင်ရာတွင် AI / Content ID စစ်ဆေးမှုများ လွှတ်စေရန် အောက်ပါ နည်းလမ်းများကို 1-Click Auto Preset ဖြင့် အသုံးချနိုင်ပါသည်။",
                                color = Color(0xFFE0E7FF),
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    GuideTechniqueItem(
                        title = "၁။ ဘယ်/ညာ ပြောင်းပြန်လှည့်ခြင်း (Horizontal Mirroring)",
                        description = "Video AI စစ်ဆေးရေးစနစ်များသည် Frame တိုင်း၏ Spatial Coordinates များကို တိုက်စစ်ပါသည်။ Mirror Flip ပြုလုပ်ခြင်းဖြင့် တိုက်ရိုက် Pixel ကိုက်ညီမှုကို ပျက်ပြယ်စေပါသည်။"
                    )

                    GuideTechniqueItem(
                        title = "၂။ Speed 1.05x မြန်နှုန်း ပြောင်းလဲခြင်း (Time-series Shift)",
                        description = "ဗီဒီယို ကြာချိန်နှင့် Keyframe Timestamp များကို ၁.၀၃x မှ ၁.၀၈x ထိ အနည်းငယ် မြန်စေခြင်းဖြင့် Audio-Visual Fingerprint Pattern ကို ကွဲပြားစေပါသည်။"
                    )

                    GuideTechniqueItem(
                        title = "၃။ အစွန်းများ ဖြတ်ထုတ်ခြင်း (Crop & Watermark Removal)",
                        description = "Xiaohongshu (小红书), Douyin, KOR 短剧 စသည့် ရေစာ Logo များ၊ ID နံပါတ်များပါသော အထက်/အောက် ဘောင်များကို ၅% မှ ၁၅% ထိ Zoom ဖြတ်ထုတ်ပါသည်။"
                    )

                    GuideTechniqueItem(
                        title = "၄။ Color Matrix & Contrast စိစစ်စနစ် (Color Grading)",
                        description = "RGB Color Spectrum နှင့် Contrast အား အနည်းငယ် ပြောင်းလဲပေးခြင်းဖြင့် Video Hash ID (MD5/SHA) ကို အသစ်စက်စက် အဖြစ် ပြောင်းလဲပေးပါသည်။"
                    )

                    GuideTechniqueItem(
                        title = "၅။ အသံ Pitch နှင့် Frequency ပြောင်းလဲခြင်း (Audio Pitch Shift)",
                        description = "အသံ Waveform Spectrogram တူညီမှုကို ကျော်လွှားရန် အသံကို +0.5st မှ +1.0st အထိ Pitch Shift မြှင့်တင်ပေးပါသည်။"
                    )

                    GuideTechniqueItem(
                        title = "၆။ နောက်ခံ ဘောင်နှင့် မြန်မာစာတန်းထိုး ထည့်သွင်းခြင်း (Value Adding)",
                        description = "ဗီဒီယို ဘေးတွင် Blurred Background / Gradient Border ထည့်ပြီး မြန်မာစာတန်းထိုးနှင့် အသံနောက်ခံ (Commentary) ထည့်သွင်းခြင်းသည် Fair Use မူဝါဒနှင့် ကိုက်ညီစေပါသည်။"
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06B6D4))
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "နားလည်ပါပြီ (1-Click စတင်မည်)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun GuideTechniqueItem(title: String, description: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Text(
            text = title,
            color = Color(0xFF06B6D4),
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = description,
            color = Color(0xFFD1D5DB),
            fontSize = 11.sp,
            lineHeight = 16.sp
        )
    }
}
