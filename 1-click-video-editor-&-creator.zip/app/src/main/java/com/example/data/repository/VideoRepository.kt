package com.example.data.repository

import com.example.data.local.VideoRecordDao
import com.example.data.model.ProcessedVideoRecord
import com.example.data.model.VideoItem
import kotlinx.coroutines.flow.Flow

class VideoRepository(private val dao: VideoRecordDao) {

    val allProcessedRecords: Flow<List<ProcessedVideoRecord>> = dao.getAllRecords()

    fun getSampleVideos(): List<VideoItem> {
        return listOf(
            VideoItem(
                id = "sample_drama_1",
                title = "KOR / Xiaohongshu Short Drama Ep.1 (တရုတ်/ကိုရီးယား ဇာတ်လမ်းတို)",
                uriPath = null,
                durationSeconds = 48,
                resolution = "1080x1920 (Vertical 9:16)",
                watermarkInfo = "Detected: KOR short drama tag (Top Right) & Xiaohongshu ID (Bottom Left)"
            ),
            VideoItem(
                id = "sample_drama_2",
                title = "Martial Arts Female Warrior Drama (သိုင်းဇာတ်လမ်းတို)",
                uriPath = null,
                durationSeconds = 62,
                resolution = "1080x1920 (Vertical 9:16)",
                watermarkInfo = "Detected: Embedded Chinese Subtitles & Channel Watermark"
            ),
            VideoItem(
                id = "sample_drama_3",
                title = "Modern Urban CEO Revenge Clip (မြို့ပြဇာတ်လမ်း)",
                uriPath = null,
                durationSeconds = 55,
                resolution = "1080x1920 (Vertical 9:16)",
                watermarkInfo = "Detected: Douyin Logo & Top Header Overlay"
            )
        )
    }

    suspend fun saveProcessedRecord(record: ProcessedVideoRecord) {
        dao.insertRecord(record)
    }

    suspend fun deleteRecord(id: Int) {
        dao.deleteRecordById(id)
    }

    suspend fun clearHistory() {
        dao.clearAll()
    }
}
