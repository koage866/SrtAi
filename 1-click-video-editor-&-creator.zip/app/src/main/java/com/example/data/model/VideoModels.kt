package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class WatermarkMaskPosition(val displayName: String) {
    NONE("မပါပါ (No Mask)"),
    TOP_RIGHT("အပေါ် ညာဘက် Logo (TikTok / Douyin)"),
    TOP_LEFT("အပေါ် ဘယ်ဘက် Logo (Kuaishou / Xiaohongshu)"),
    BOTTOM_RIGHT("အောက် ညာဘက် Watermark"),
    TOP_BOTTOM_BARS("အပေါ် / အောက် ဘောင် ၂ ဖက်စလုံး")
}

enum class ColorFilterType(val displayName: String) {
    NONE("Normal"),
    VIBRANT_DRAMA("Vibrant Drama (တောက်ပြောင်)"),
    WARM_SUNSET("Warm Sunset (နွေးထွေး)"),
    DARK_CINEMATIC("Dark Cinematic (ရုပ်ရှင်ဆန်)"),
    HIGH_CONTRAST("High Contrast (ပြတ်သား)"),
    VINTAGE_NOSTALGIA("Vintage (ရှေးဟောင်း)")
}

enum class FrameOverlayStyle(val displayName: String) {
    NONE("No Frame (မူလအတိုင်း)"),
    BLUR_CANVAS("Blurred Background (နောက်ခံဝေဝါး)"),
    GRADIENT_BORDER("Gradient Border (ရောင်စုံအနား)"),
    CINEMATIC_BOX("Cinematic Letterbox (ရုပ်ရှင်ဘောင်)"),
    NEWS_LOWER_THIRD("News Banner (သတင်းဘောင်)"),
    CUSTOM_TEXT("Custom Text Banner (စာတန်းပါဘောင်)")
}

data class PresetConfig(
    val isMirrorFlipped: Boolean = false, // Horizontal Mirroring
    val speedMultiplier: Float = 1.05f,
    val cropZoomPercent: Float = 8f,
    val topCropPercent: Float = 6f,
    val bottomCropPercent: Float = 6f,
    val colorFilter: ColorFilterType = ColorFilterType.VIBRANT_DRAMA,
    val frameOverlayStyle: FrameOverlayStyle = FrameOverlayStyle.BLUR_CANVAS,
    val customOverlayText: String = "▶ ဇာတ်လမ်းတို အပိုင်း (၁) | Short Drama",
    val audioPitchShift: Float = 0.5f,
    val volumeMultiplier: Float = 1.1f,
    val addBackgroundGrain: Boolean = true,
    // 1s - 3s Short Clips Split & Shuffle Engine
    val enableShortClipSlicing: Boolean = true,  // 1s-3s Short Clips Auto Split
    val clipSliceDurationSeconds: Float = 2.0f, // Duration per short clip
    val enableClipShuffling: Boolean = true,     // Reorder/Shuffle split clips
    // Watermark Blur & Crop Mask Settings
    val enableWatermarkBlurMask: Boolean = true,
    val watermarkMaskPosition: WatermarkMaskPosition = WatermarkMaskPosition.TOP_RIGHT,
    val watermarkBlurSizePercent: Float = 16f,
    // 2s - 3s Dynamic Keyframe Modulation
    val enableDynamicMicroCuts: Boolean = true,  // 2s-3s micro frame cut
    val enableDynamicZoomPulse: Boolean = true,  // 2s-3s crop zoom pulse
    val enableDynamicColorPulse: Boolean = true, // 2s-3s brightness/color shift
    val enableDynamicAudioPulse: Boolean = true, // 2s-3s audio pitch/speed pulse
    val dynamicIntervalSeconds: Float = 2.5f     // Every 2.5 seconds
) {
    companion object {
        val DEFAULT_AUTO_BYPASS = PresetConfig()
        
        val DRAMA_PRESET = PresetConfig(
            isMirrorFlipped = false,
            speedMultiplier = 1.06f,
            cropZoomPercent = 10f,
            topCropPercent = 8f,
            bottomCropPercent = 8f,
            colorFilter = ColorFilterType.DARK_CINEMATIC,
            frameOverlayStyle = FrameOverlayStyle.BLUR_CANVAS,
            customOverlayText = "🔥 ကြည့်ရှုသူများပြားသော ဇာတ်လမ်းတို",
            audioPitchShift = 0.8f,
            enableShortClipSlicing = true,
            clipSliceDurationSeconds = 2.0f,
            enableClipShuffling = true,
            enableWatermarkBlurMask = true,
            watermarkMaskPosition = WatermarkMaskPosition.TOP_RIGHT,
            enableDynamicMicroCuts = true,
            enableDynamicZoomPulse = true,
            enableDynamicColorPulse = true,
            enableDynamicAudioPulse = true,
            dynamicIntervalSeconds = 2.5f
        )
        
        val TIKTOK_PRESET = PresetConfig(
            isMirrorFlipped = true,
            speedMultiplier = 1.04f,
            cropZoomPercent = 7f,
            topCropPercent = 5f,
            bottomCropPercent = 5f,
            colorFilter = ColorFilterType.VIBRANT_DRAMA,
            frameOverlayStyle = FrameOverlayStyle.GRADIENT_BORDER,
            customOverlayText = "✨ Viral Trending Clip",
            audioPitchShift = 0.4f,
            enableShortClipSlicing = true,
            clipSliceDurationSeconds = 1.5f,
            enableClipShuffling = true,
            enableWatermarkBlurMask = true,
            watermarkMaskPosition = WatermarkMaskPosition.TOP_RIGHT,
            enableDynamicMicroCuts = true,
            enableDynamicZoomPulse = true,
            enableDynamicColorPulse = true,
            enableDynamicAudioPulse = true,
            dynamicIntervalSeconds = 2.0f
        )
    }
}

data class VideoItem(
    val id: String,
    val title: String,
    val uriPath: String?,
    val durationSeconds: Int,
    val resolution: String = "1080x1920",
    val sampleVideoResId: Int? = null,
    val watermarkInfo: String = "Xiaohongshu / KOR Drama Watermark Detected"
)

@Entity(tableName = "processed_video_records")
data class ProcessedVideoRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originalTitle: String,
    val processedFileName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val fingerprintScore: Float, // e.g. 98.5% unique
    val presetAppliedSummary: String,
    val fileSizeBytes: Long = 18450000L,
    val videoUriPath: String? = null,
    val savedMediaUri: String? = null,
    val savedStoragePath: String? = null
)
