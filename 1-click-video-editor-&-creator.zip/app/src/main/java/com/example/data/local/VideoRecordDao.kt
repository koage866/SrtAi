package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.ProcessedVideoRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoRecordDao {
    @Query("SELECT * FROM processed_video_records ORDER BY timestamp DESC")
    fun getAllRecords(): Flow<List<ProcessedVideoRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: ProcessedVideoRecord)

    @Query("DELETE FROM processed_video_records WHERE id = :id")
    suspend fun deleteRecordById(id: Int)

    @Query("DELETE FROM processed_video_records")
    suspend fun clearAll()
}
